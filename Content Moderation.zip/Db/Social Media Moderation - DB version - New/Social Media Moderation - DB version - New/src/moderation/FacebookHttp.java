package moderation;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class FacebookHttp {

	public ArrayList<String> getUserTimeline() 
	{
		
		// TODO Auto-generated method stub
		HttpClient httpclient = HttpClients.createDefault();
		ArrayList<String> posts = new ArrayList<>();
		try {
		URIBuilder builder = new URIBuilder("https://graph.facebook.com/v7.0/me/posts?access_token=EAANhQzUdw0wBAKh2jtgS4EkeNGHL6KQXqgZCYnj4YC3BZC0LtJ5fYJhW6JACU4LjaqM6ZBjpZADpHp9vTvGwNfJ71BSALPMeyCnJf1bxdJBGA24yIqmHWPQlMQnn2O9qvmKcnicQWPDW99THMd02vzKpGZBBKOXZBzRLprqTpZATulBRTZAj18m8");
		
		URI uri = builder.build();
		HttpGet request = new HttpGet(uri);
		//HttpPost request= new HttpPost(uri);
		
		 
		 //get response
		 HttpResponse response = httpclient.execute(request);
		 HttpEntity entity = response.getEntity();
		
		 
		 if(entity!=null)
		 {
			 int i; 
			 String s = EntityUtils.toString(entity);
			 JSONObject object = new JSONObject(s);
			 JSONArray data = object.getJSONArray("data");
			 if(data.length()>0)
			 {
				 for(i=0;i<10;i++)
				 {
					 JSONObject info = data.getJSONObject(i);
					 if(info.has("message"))
					 {
						 String message = info.getString("message");
						 posts.add(message); 
						 
						 String id = info.getString("id");
						 System.out.println(id);
						 posts.add(id);
					 }
					 
				 }
				 return posts;
			 }
		 }
		return posts;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			posts.add("error");
			return posts;
		}
	}
	
	public ArrayList<String> getFacebookComments(String postId) 
	{
		
		// TODO Auto-generated method stub
		HttpClient httpclient = HttpClients.createDefault();
		ArrayList<String> posts = new ArrayList<>();
		try {
		URIBuilder builder = new URIBuilder("https://graph.facebook.com/v8.0/"+postId+"/comments?access_token=EAANhQzUdw0wBAKh2jtgS4EkeNGHL6KQXqgZCYnj4YC3BZC0LtJ5fYJhW6JACU4LjaqM6ZBjpZADpHp9vTvGwNfJ71BSALPMeyCnJf1bxdJBGA24yIqmHWPQlMQnn2O9qvmKcnicQWPDW99THMd02vzKpGZBBKOXZBzRLprqTpZATulBRTZAj18m8");
		URI uri = builder.build();
		HttpGet request = new HttpGet(uri);
		//HttpPost request= new HttpPost(uri);
		
		 
		 //get response
		 HttpResponse response = httpclient.execute(request);
		 HttpEntity entity = response.getEntity();
		 
		 if(entity!=null)
		 {
			 int i; 
			 String s = EntityUtils.toString(entity);
			 JSONObject object = new JSONObject(s);
			 JSONArray data = object.getJSONArray("data");
			 if(data.length()>0)
			 {
				 for(i=0;i<data.length();i++)
				 {
					 JSONObject info = data.getJSONObject(i);
					 if(info.has("message"))
					 {
						 String message = info.getString("message");
						 posts.add(message); 
						 
						 String id = info.getString("id");
						// posts.add(id);
					 }
					 
				 }
				 return posts;
			 }
		 }
		return posts;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			posts.add("error");
			return posts;
		}
	}
	
	public ArrayList<String> getPagePosts() 
	{
		
		// TODO Auto-generated method stub
		HttpClient httpclient = HttpClients.createDefault();
		ArrayList<String> posts = new ArrayList<>();
		try {
		URIBuilder builder = new URIBuilder("https://graph.facebook.com/v7.0/me/posts?access_token=EAANhQzUdw0wBAEhmYapFJi2HQOJ54ayT9WeY31QVpnYBKS3PZC6bKt6rBNdS0RfxWjTfVlENAYuAgBdla4UfjqScq8qCSTOvH96uY0W0WthPTnR49BTfjZAcWz9P3M9zCGaVNJnHmBJEwZA2rp5nZB1TVgPayfCdLBUsrcZAHYcWPJn15h9oo85INMsP6EacZD");
		
		URI uri = builder.build();
		HttpGet request = new HttpGet(uri);
		//HttpPost request= new HttpPost(uri);
		
		 
		 //get response
		 HttpResponse response = httpclient.execute(request);
		 HttpEntity entity = response.getEntity();
		 
		 if(entity!=null)
		 {
			 int i; 
			 String s = EntityUtils.toString(entity);
			 JSONObject object = new JSONObject(s);
			 JSONArray data = object.getJSONArray("data");
			 if(data.length()>0)
			 {
				 for(i=0;i<data.length();i++)
				 {
					 JSONObject info = data.getJSONObject(i);
					 if(info.has("message"))
					 {
						 String message = info.getString("message");
						 posts.add(message); 
					 }
					 
				 }
				 return posts;
			 }
		 }
		return posts;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			posts.add("error");
			return posts;
		}
	}
	
	
	public static void main(String[] args) throws ParseException, IOException, URISyntaxException {
		// TODO Auto-generated method stub
			FacebookHttp fb = new FacebookHttp();
			System.out.println(fb.getFacebookComments("108670474242427_152174873225320"));
	}

}

package moderation;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import org.apache.catalina.User;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mongodb.util.JSON;


@Controller
public class controller {
	
	//global lists for twitter
	ArrayList<String> toxicity = new ArrayList<>();
	ArrayList<Double> toxicity_value = new ArrayList<>();
	ArrayList<String> image_res = new ArrayList<>();
	ArrayList<String> intents = new ArrayList<String>();
	ArrayList<String> sentiments = new ArrayList<String>();
	ArrayList<String> emotions = new ArrayList<String>();
	ArrayList<ArrayList<String>> moderatedText2= new ArrayList<>(); 
	ArrayList<ArrayList<String>> type = new ArrayList<>();
	
	
	ArrayList<String> list = new ArrayList<String>();
	ArrayList<String> list1 = new ArrayList<String>();
	ArrayList<String> list2= new ArrayList<String>();
	ArrayList<String> list3= new ArrayList<String>();
	ArrayList<String> list4= new ArrayList<String>();
	
	//Global lists for youtube
	ArrayList<String>  ylist1 = new ArrayList<String>();
	ArrayList<String> ylist2= new ArrayList<String>();
	ArrayList<String> listtwo= new ArrayList<String>();

	//global lists for facebook
	ArrayList<String> flist1 = new ArrayList<String>();
	ArrayList<String> flist2 = new ArrayList<String>();
	ArrayList<ArrayList<String>> moderated = new ArrayList<>();
	ArrayList<String> listone = new ArrayList<String>();
	ArrayList<String> fblist = new ArrayList<String>();
	
	//global lists for checking used resources status.
	JSONArray sight_engine = new JSONArray();
	JSONArray moderate_content = new JSONArray();
	JSONArray parallel_dots = new JSONArray();
	
	@RequestMapping("/gotoHome")
	public String redirect1(Model model) {
		
		return "home";
	}	
	
	@RequestMapping("/gotoSearchOccurrences")
	public String redirect2(Model model) {
		
		return "searchOccurrences";
	}
	
	@RequestMapping("/gotoSearchQuery")
	public String redirect3(Model model) {
		
		return "twitterSearch";
	}
	
	@RequestMapping("/gotoCommentList")
	public String redirect4(Model model) {
		
		return "commentList";
	}
	@RequestMapping("/gotoFetchYoutubeVideos")
	public String redirect5(Model model) {
		
		return "fetchYoutubeVideos";
	}
	@RequestMapping("/gotoAddUsers")
	public String redirect6(Model model) {
		
		ArrayList<String> user = new ArrayList<>();
		ArrayList<String> fname = new ArrayList<>();
		ArrayList<String>  lname = new ArrayList<>();
		ArrayList<String>  email = new ArrayList<>();
		Database db = new Database();
		user = db.getUsersFromDB();
		if(user.size()==0)
		{
			model.addAttribute("error", "1");
		}
		else {
			int i =0 ; 
			while(i<user.size())
			{
				fname.add(user.get(i));
				email.add(user.get(i+1));
				lname.add(user.get(i+2));
				i=i+3;
			}
			model.addAttribute("fname", fname);
			model.addAttribute("lname", lname);
			model.addAttribute("email", email);
			
			
		}
		return "addUsers";
	}
	
	@RequestMapping("/generate")
	public String generateWordCloud(Model model, String platform) {
		System.out.print(platform);
//		if(platform==null)
//		{
//			platform="TwitterResults";
//		}
		HashMap<String, Integer> h = new HashMap<>();
		Database db = new Database();
		h=db.getBadWordCount(platform);
		JSONArray words = new JSONArray();
		int i =0 ;
		// Finding the Set of keys from 
        // the HashMap 
        Set<String> keySet = h.keySet(); 
  
        // Creating an ArrayList of keys 
        // by passing the keySet 
        ArrayList<String> listOfKeys = new ArrayList<String>(keySet); 
  
        // Getting Collection of values from HashMap 
        Collection<Integer> values = h.values(); 
  
        // Creating an ArrayList of values 
        ArrayList<Integer> listOfValues = new ArrayList<>(values); 
		while(i<h.size())
		{
			JSONObject ob = new JSONObject();
			ob.put("tag", listOfKeys.get(i));
			ob.put("count", String.valueOf(listOfValues.get(i)));
			words.put(ob);
			i++;
		
		}
		model.addAttribute("plat", platform);
		model.addAttribute("words", words);
		return "words";
	}
	
	
	
	@RequestMapping("/createUsedResourcesGraph")
	public String populateUsedResources(Model model) throws IOException
	{
		JSONArray ModerateContentresponse = new JSONArray();
		JSONArray ParallelDotsresponse = new JSONArray();
		
		Database db = new Database();
		ModerateContentresponse = db.checkResourceUsed("ModerateContent");

		ParallelDotsresponse = db.checkResourceUsed("ParallelDots");
		
		createUsedResourcesGraph(model, ModerateContentresponse, ParallelDotsresponse);
		
		return "resourcesUsed";
		
	}
	
	@RequestMapping("/sendResponseInMail")
	public String sendResponseInMail(Model model, String email, String platform) throws IOException
	{
		System.out.println("platfomr"+platform);
		HashMap<String, Integer> count = new HashMap<>();
		Database db = new Database();
		count = db.getBadWordCount(platform);
		Mail m = new Mail();
		int i = 0; 
		 Set<String> keySet = count.keySet(); 
		  
	        // Creating an ArrayList of keys 
	        // by passing the keySet 
	        ArrayList<String> listOfKeys = new ArrayList<String>(keySet); 
	  
	        // Getting Collection of values from HashMap 
	        Collection<Integer> values = count.values(); 
	  
	        // Creating an ArrayList of values 
	        ArrayList<Integer> listOfValues = new ArrayList<>(values);
		
		String s = "Bad Words Encountered :   \n";
		while(i < listOfKeys.size())
		{
			s= s.concat(listOfKeys.get(i).toString()+"-------->"+listOfValues.get(i).toString())+"\n";
			i++;
		}
		m.send(email, "Response from Content Moderator", s);
		return "home";
		
	}
	
	
	public String createUsedResourcesGraph(Model model, JSONArray doc, JSONArray doc1) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		JSONArray ModerateContentresponse = new JSONArray();
		JSONArray ParallelDotsresponse = new JSONArray();
	
		System.out.println("doc="+doc);
		System.out.println("doc1="+doc1);
		
		ModerateContentresponse = doc;
		ParallelDotsresponse = doc1;
		
		int k,countm=0;
		Double tox_val=null;
		for(k=0; k<ModerateContentresponse.length();k++)
		{
			String s = ModerateContentresponse.get(k).toString();
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				try {
				int count1 = ob.getInt("count");
				countm=countm+count1;
				}
				catch(Exception e )
				{
					int count1=0;
					countm=countm+count1;	
				}
				
			}
		}
		int countp =0 ;
		for(k=0; k<ParallelDotsresponse.length();k++)
		{
			String s = ParallelDotsresponse.get(k).toString();
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				try {
				int count1 = ob.getInt("count");
				countp=countp+count1;
				}
				catch(Exception e)
				{
					 int count1=0;
					 countp=countp+count1;
				}
				
				
			}
		}
		
		JSONArray services = new JSONArray();
		
		JSONObject data1 = new JSONObject();
		data1.put("category", "Moderate Content");
		data1.put("value", countm);
		services.put(data1);
		
		JSONObject data2 = new JSONObject();
		data2.put("category", "ParallelDots");
		data2.put("value", countp);
		services.put(data2);
		
		model.addAttribute("services", services);
		System.out.println("serv= "+services);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "resourcesUsed";
		}
		
		return "resourcesUsed";
	}
	
	@RequestMapping("/createTwitterGraph")
	public String createTwitterGraph(Model model, JSONArray doc) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0,complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		response = db.getTweetsfromDB();
		//response = doc;
		//response = db.readcontentfromJSON();
		System.out.println("response="+response);
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			
			response=doc;
		}
		
		
		JSONArray response_image = new JSONArray();
		//response_image = doc2;
		response_image = db.getImagefromDB();
		//response_image = db.readImagesfromJSON();
		System.out.println(response_image);
		
		int l, obj_image =0, safe_image=0, count_img=0;
		for(l=0;l<response_image.length();l++)
		{
			String s = response_image.get(l).toString();
			JSONObject j = new JSONObject(s);
			if(j.has("error"))
			{
				//throw error
			}
			else
			{
				count_img++;
				if(!(j.getString("review").equalsIgnoreCase("yes")))
				{
					safe_image++;
				}
				else
				{
					obj_image++;
				}
			}
			
			
		}
		JSONArray image = new JSONArray();
		JSONObject image_data1 = new JSONObject();
		
		image_data1.put("category","Safe Images");
		image_data1.put("value", safe_image);
		image.put(image_data1);		
		
JSONObject image_data2 = new JSONObject();
		
		image_data2.put("category","Review Recommended");
		image_data2.put("value", obj_image);
		image.put(image_data2);
		
		model.addAttribute("image", image);
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			//System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;
				
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray images_vs_text = new JSONArray();
		JSONObject images = new JSONObject();
		
		images.put("category","Images");
		images.put("value", count_img);
		images_vs_text.put(images);
		
JSONObject texts = new JSONObject();
		
		texts.put("category","Texts");
		texts.put("value", count);
		images_vs_text.put(texts);
		
		model.addAttribute("image_vs_texts", images_vs_text);
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "News");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data6.put("category", "Complaint");
		intent_data6.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data6.put("category", "Excited");
		emotion_data6.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("intent", intent);
		model.addAttribute("sentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		
		}
		catch(Exception e)
		{
			return "twitterCharts";
		}
		
		return "twitterCharts";
	}
	
	@RequestMapping("/createFacebookGraph")
	public String createFaceBookGraph(Model model, JSONArray doc) throws IOException {
		
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0, complaint=0 ;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		response = db.getFbPostsfromDB();
		//response =db.readcontentfromJSON();
		//response = docs;
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++; 
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "News");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data6.put("category", "Complaint");
		intent_data6.put("value", complaint);
		intent.put(intent_data6);
		
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data6.put("category", "Excited");
		emotion_data6.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("intent", intent);
		model.addAttribute("sentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		
		System.out.println("Emotion"+emotion);
		}
		catch(Exception e)
		{
		return "facebookCharts";
		}
		return "facebookCharts";
	}
	
	@RequestMapping("/getfbcc")
	public void getFacebookcc(Model model, JSONArray doc) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0,complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		response = db.getFbPostsfromDB();
		//response =db.readcontentfromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;
							
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "News");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data5.put("category", "Complaint");
		intent_data5.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data1.put("category", "Excited");
		emotion_data1.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("fbintent", intent);
		model.addAttribute("fbsentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		}
		catch(Exception e)
		{
			
		}
		
	}
	
	@RequestMapping("/gotoTwittercc")
	public void getTwittercc(Model model, JSONArray doc) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0,complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		response = db.getTweetsfromDB();

		//response = db.readcontentfromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		JSONArray response_image = new JSONArray();
		response_image = db.getImagefromDB();
		//response_image = db.readImagesfromJSON();
		System.out.println(response_image);
		
		int l, obj_image =0, safe_image=0, count_img=0;
		for(l=0;l<response_image.length();l++)
		{
			String s = response_image.get(l).toString();
			JSONObject j = new JSONObject(s);
			if(j.has("error"))
			{
				//throw error
			}
			else
			{
				count_img++;
				if(!(j.getString("review").equalsIgnoreCase("yes")))
				{
					safe_image++;
				}
				else
				{
					obj_image++;
				}
			}
			
			
		}
		JSONArray image = new JSONArray();
		JSONObject image_data1 = new JSONObject();
		
		image_data1.put("category","Safe Images");
		image_data1.put("value", safe_image);
		image.put(image_data1);		
		
JSONObject image_data2 = new JSONObject();
		
		image_data2.put("category","Review Recommended");
		image_data2.put("value", obj_image);
		image.put(image_data2);
		
		model.addAttribute("image", image);
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;
								
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray images_vs_text = new JSONArray();
		JSONObject images = new JSONObject();
		
		images.put("category","Images");
		images.put("value", count_img);
		images_vs_text.put(images);
		
JSONObject texts = new JSONObject();
		
		texts.put("category","Texts");
		texts.put("value", count);
		images_vs_text.put(texts);
		
		model.addAttribute("image_vs_texts", images_vs_text);
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "News");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data6.put("category", "Complaint");
		intent_data6.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data1.put("category", "Excited");
		emotion_data1.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("twitterintent", intent);
		model.addAttribute("twittersentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		System.out.println("intent="+intent);
		}
		catch(Exception e)
		{
			
		}
		
	}
	
	@RequestMapping("/createInstaGraph")
	public String createInstagramGraph(Model model, JSONArray doc) throws IOException {
		
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0, complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		Database db = new Database();
		response = db.getInstaPostsfromDB();
		//response = db.readinstafromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "News");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data5.put("category", "Complaint");
		intent_data5.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data6.put("category", "Excited");
		emotion_data6.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("intent", intent);
		model.addAttribute("sentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);

		return "instagramCharts";
		}
		catch(Exception e)
		{
			return "instagramCharts";
		}
	}
	

	@RequestMapping("/createYoutubeGraph")
	public String createYoutubeGraph(Model model, JSONArray doc) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0, complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		Database db = new Database();
		response = db.getYoutubeCommentsfromDB();
		//response = db.readcontentfromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "News");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data6.put("category", "Comaplaint");
		intent_data6.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data6.put("category", "Excited");
		emotion_data6.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("intent", intent);
		model.addAttribute("sentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		}
		catch(Exception e)
		{
			return "youTubeCharts";
		}
		return "youTubeCharts";
		
	}
		
	
	@RequestMapping("/gotoYoutubecc")
	public void getYoutubecc(Model model, JSONArray doc) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0,complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		response = db.getYoutubeCommentsfromDB();
		//response = db.readcontentfromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;	
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "News");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data6.put("category", "Complaint");
		intent_data6.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data6.put("category", "Excited");
		emotion_data6.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("youtubeintent", intent);
		model.addAttribute("youtubesentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		}
		catch(Exception e)
		{
			
		}
	}
	
	@RequestMapping("/gotoInstacc")
	public void getInstagramcc(Model model, JSONArray doc) throws IOException {
		try {
		ArrayList<Double> tox_dbvalue = new ArrayList<>();
		int marketing=0,spam=0,news=0,query=0,feedback=0,complaint=0;
		int bored=0, angry=0, sad=0 , fear=0, happy=0, excited=0;
		int negative=0, neutral=0, positive=0; 
		int count_yes=0, count_no=0;
		JSONArray response = new JSONArray();
		
		Database db = new Database();
		response = db.getInstaPostsfromDB();
		//response = db.readcontentfromJSON();
		if(!(doc.toString().equalsIgnoreCase("[]")))
		{
			
			System.out.println("You are here");
			System.out.println(doc);
			response=doc;
		}
		
		int k,count=0;
		Double tox_val=null;
		for(k=0; k<response.length();k++)
		{
			String s = response.get(k).toString();
			System.out.println("s= "+s);
			JSONObject ob = new JSONObject(s);
			if(ob.has("error"))
			{
				//throw error
			}
			else
			{
				count++;	
				//intent cal 
				
				String intent = ob.getString("Intent");
				if(intent.toString().equalsIgnoreCase("marketing"))
				{
					marketing++;
				}
				else if(intent.toString().equalsIgnoreCase("news"))
				{
					news++;
				}
				else if(intent.toString().equalsIgnoreCase("query"))
				{
					query++;
				}
				else if(intent.toString().equalsIgnoreCase("complaint"))
				{
					complaint++;
				}
				else if(intent.toString().equalsIgnoreCase("spam"))
				{
					spam++;
				}
				else
				{
					feedback++;
				}
				
				//calculating emotion
				String emotion = ob.getString("Emotion");
				if(emotion.toString().equalsIgnoreCase("bored"))
				{
					bored++;
				}
				else if(emotion.toString().equalsIgnoreCase("angry"))
				{
					angry++;
				}
				else if(emotion.toString().equalsIgnoreCase("sad"))
				{
					sad++;
				}
				else if(emotion.toString().equalsIgnoreCase("fear"))
				{
					fear++;
				}
				else if(emotion.toString().equalsIgnoreCase("happy"))
				{
					happy++;
				}
				else
				{
					excited++;
				}
				
				//calculating sentiment
				String sentiment = ob.getString("Sentiment");
				if(sentiment.toString().equalsIgnoreCase("negative"))
				{
					negative++;
				}
				else if(sentiment.toString().equalsIgnoreCase("neutral"))
				{
					neutral++;
				}
				else
				{
					positive++;
				}
				//calculating review
				String review = ob.getString("Review");
				if(review.toString().equalsIgnoreCase("yes"))
				{
					count_yes++;
				}
				else
				{
					count_no++;
				}
				
			}
			tox_dbvalue.add(tox_val);
		}
		
		JSONArray tox_data = new JSONArray();
		int a=0;
		while(a<tox_dbvalue.size())
		{
			JSONObject tox_data1 = new JSONObject();
			tox_data1.put("category", a);
			tox_data1.put("value", tox_dbvalue.get(a));
			tox_data.put(tox_data1);
			a++;
		}
		model.addAttribute("tox_val",tox_data);
		
		JSONArray intent = new JSONArray();
		
		JSONObject intent_data1 = new JSONObject();
		intent_data1.put("category", "News");
		intent_data1.put("value", news);
		intent.put(intent_data1);
		
		JSONObject intent_data2 = new JSONObject();
		intent_data2.put("category", "Query");
		intent_data2.put("value", query);
		intent.put(intent_data2);

		JSONObject intent_data3 = new JSONObject();
		intent_data3.put("category", "Spam");
		intent_data3.put("value", spam);
		intent.put(intent_data3);
		
		JSONObject intent_data4 = new JSONObject();
		intent_data4.put("category", "Feedback");
		intent_data4.put("value", feedback);
		intent.put(intent_data4);
		
		JSONObject intent_data5 =  new JSONObject();
		intent_data5.put("category", "Marketing");
		intent_data5.put("value", marketing);
		intent.put(intent_data5);
		
		JSONObject intent_data6 =  new JSONObject();
		intent_data6.put("category", "Complaint");
		intent_data6.put("value", complaint);
		intent.put(intent_data6);
		
JSONArray emotion = new JSONArray();
		
		JSONObject emotion_data1 = new JSONObject();
		emotion_data1.put("category", "Bored");
		emotion_data1.put("value", bored);
		emotion.put(emotion_data1);
		
		JSONObject emotion_data2 = new JSONObject();
		emotion_data2.put("category", "Angry");
		emotion_data2.put("value", angry);
		emotion.put(emotion_data2);
		
		JSONObject emotion_data3 = new JSONObject();
		emotion_data3.put("category", "Sad");
		emotion_data3.put("value", sad);
		emotion.put(emotion_data3);
		
		JSONObject emotion_data4 = new JSONObject();
		emotion_data4.put("category", "Fear");
		emotion_data4.put("value", fear);
		emotion.put(emotion_data4);
		
		JSONObject emotion_data5 = new JSONObject();
		emotion_data5.put("category", "Happy");
		emotion_data5.put("value", happy);
		emotion.put(emotion_data5);
		
		JSONObject emotion_data6 = new JSONObject();
		emotion_data6.put("category", "Excited");
		emotion_data6.put("value", excited++);
		emotion.put(emotion_data6);
		
JSONArray sentiment = new JSONArray();
		
		JSONObject sentiment_data1 = new JSONObject();
		sentiment_data1.put("category", "Negative");
		sentiment_data1.put("value", negative);
		sentiment.put(sentiment_data1);
		
		JSONObject sentiment_data2 = new JSONObject();
		sentiment_data2.put("category", "Positive");
		sentiment_data2.put("value", positive);
		sentiment.put(sentiment_data2);
		
		JSONObject sentiment_data3 = new JSONObject();
		sentiment_data3.put("category", "Neutral");
		sentiment_data3.put("value", neutral);
		sentiment.put(sentiment_data3);
		
JSONArray review= new JSONArray();
		
		JSONObject review_data1 = new JSONObject();
		review_data1.put("category", "Review Recommended");
		review_data1.put("value", count_yes);
		review.put(review_data1);
		
		JSONObject review_data2 = new JSONObject();
		review_data2.put("category", "Safe Content");
		review_data2.put("value", count_no);
		review.put(review_data2);
		
		model.addAttribute("instaintent", intent);
		model.addAttribute("instasentiment", sentiment);
		model.addAttribute("emotion", emotion);
		model.addAttribute("review", review);
		}
		catch(Exception e)
		{
			
		}
	}
	
	@RequestMapping("/populateCommandCenter")
	public String populateCommandCenter( Model model) throws java.lang.Exception {
		JSONArray ar = new JSONArray();
		getFacebookcc(model,ar);
		getTwittercc(model,ar);
		getYoutubecc(model,ar);
		getInstagramcc(model,ar);
	return "commandCenter";
	
	}
		
	@RequestMapping("/fetchErrors")
	public String fetchErrors(Model model)
	{
		ArrayList<String> err = new ArrayList<>();
		ArrayList<String> desc = new ArrayList<>();
		ArrayList<String> date = new ArrayList<>();
		ArrayList<String> platform = new ArrayList<>();
		Database db = new Database();
		err = db.getErrors();
		int i =0 ; 
		while(i<err.size())
		{
			desc.add(err.get(i));
			date.add(err.get(i+1));
			platform.add(err.get(i+2));
			i=i+3;
			
		}
		model.addAttribute("desc", desc);
		model.addAttribute("date", date);
		model.addAttribute("platform", platform);
		return "errorLogs";
	}
	
	@RequestMapping("/addUsers")
	public String addUsers(Model model, String fname, String lname, String email)
	{
		Database db = new Database();
		int response  = db.saveUser(fname, lname, email);
		if(response == 1)
		{
			model.addAttribute("message", "User added");
		}
		else if(response == -1)
		{
			model.addAttribute("message", "E-mail already exists");
		}
		redirect6(model);
		return "addUsers";
	}
	// deleting a user
	
	  @RequestMapping("/deleteUsers") 
	  public String deleteUsers(Model model, String email) {
	  
	  
	  Database db= new Database(); 
	  int response= db.deleteUser(email);
	  if(response ==1)
	  {
		  model.addAttribute("message", "User Deleted");
	  }
	  else if(response == -1)
	  {
		  model.addAttribute("message", "E-mail already exists");
	  }
	  redirect6(model);
	  return "addUsers"; 
	  }
	 
	
	@RequestMapping("/generateTimeline")
	public String generateTimeline(Model model,HttpSession session) throws java.lang.Exception {
		try {
			System.out.println(session.getAttribute("username"));
		{
		TwitterClass f = new TwitterClass();
		list.clear();
		list1.clear();
		list2.clear();
		list3.clear();
		list4.clear();
		ArrayList<String> id = new ArrayList<String>();
		Database db = new Database();
		id=db.checkDuplicate("TwitterResults");
		list = f.getTimeLine();
		int i=0;
		while(i<list.size())
		{
			list1.add(list.get(i));
			list2.add(list.get(i+1));
			list3.add(list.get(i+2));
			list4.add(list.get(i+3));
			i=i+4;
		}
         
		db.unmoderatedTweets(list1, list2, list3, list4);
		
		list.clear();
		list1.clear();
		list2.clear();
		list3.clear();
		list4.clear();
		ArrayList<String> images = new ArrayList<>();
		ArrayList<String> badWords = new ArrayList<>();
		ArrayList<String> review = new ArrayList<>();
		list = db.getTweets("TwitterResults");
		i=0;
		while(i<list.size())
		{
			list1.add(list.get(i));   //tweet
			images.add(list.get(i+1));
			badWords.add(list.get(i+2));
			review.add(list.get(i+3));
			list2.add(list.get(i+4)); //emotion
			list3.add(list.get(i+5)); //sentiment
			list4.add(list.get(i+6)); //intent
			i=i+7;
		}
		model.addAttribute("original", list1);
		model.addAttribute("image_res", images);
		model.addAttribute("words", badWords);
		model.addAttribute("toxicity", review);
		model.addAttribute("emotion", list2);
		model.addAttribute("sentiment", list3);
		model.addAttribute("intent", list4);
		
		}
		}		catch(Exception e)
		{
			String s1 = e.getMessage();
			String platform="Twitter";
			Database db = new Database();
			db.saveErrors(s1,platform);
			model.addAttribute("err","Server Overloaded");
			e.printStackTrace();
			return "twitterDashboard";
		}
		
		return "twitterDashboard";
	}
	
	
	@RequestMapping("/getNoonTweets")
	public String getNoonTweets(Model model)
	{
		Database db=new Database();
		list.clear();
		list1.clear();
		list2.clear();
		list3.clear();
		list4.clear();
		ArrayList<String> images = new ArrayList<>();
		ArrayList<String> badWords = new ArrayList<>();
		ArrayList<String> review = new ArrayList<>();
		list = db.getTweets("TwitterSearchResults");
		int i=0;
		while(i<list.size())
		{
			list1.add(list.get(i));   //tweet
			images.add(list.get(i+1));
			badWords.add(list.get(i+2));
			review.add(list.get(i+3));
			list2.add(list.get(i+4)); //emotion
			list3.add(list.get(i+5)); //sentiment
			list4.add(list.get(i+6)); //intent
			i=i+7;
		}
		model.addAttribute("removeSearch","1");
		model.addAttribute("original", list1);
		model.addAttribute("image_res", images);
		model.addAttribute("words", badWords);
		model.addAttribute("toxicity", review);
		model.addAttribute("emotion", list2);
		model.addAttribute("sentiment", list3);
		model.addAttribute("intent", list4);
			
		
		return "twitterSearch";
	}

	@RequestMapping("/getNoonFacebookPost")
	public String getNoonFacebookPost(Model model)
	{
		Database db=new Database();
		list.clear();
		list1.clear();
		list2.clear();
		list3.clear();
		list4.clear();
		ArrayList<String> type = new ArrayList<>();
		ArrayList<String> badWords = new ArrayList<>();
		ArrayList<String> review = new ArrayList<>();
		list = db.getFbPosts();
		int i=0;
		while(i<list.size())
		{
			list1.add(list.get(i));   //tweet
			badWords.add(list.get(i+1));
			
			
			review.add(list.get(i+2));
			list2.add(list.get(i+3)); //emotion
			list3.add(list.get(i+4)); //sentiment
			list4.add(list.get(i+5)); //intent
			type.add(list.get(i+6));
			i=i+7;
		}
		//model.addAttribute("removeSearch","1");
		model.addAttribute("original", list1);
		model.addAttribute("type", type);
		model.addAttribute("words", badWords);
		model.addAttribute("toxicity", review);
		model.addAttribute("emotion", list2);
		model.addAttribute("sentiment", list3);
		model.addAttribute("intent", list4);
			
		
		return "fetchFacebookTimeline";
	}
	@RequestMapping("/getNoonInstagram")
	public String getNoonInstagram(Model model)
	{
		Database db=new Database();
		list.clear();
		list1.clear();
		list2.clear();
		list3.clear();
		list4.clear();
		ArrayList<String> image_res = new ArrayList<>();
		ArrayList<String> badWords = new ArrayList<>();
		ArrayList<String> review = new ArrayList<>();
		list = db.getInstaPosts();
		int i=0;
		while(i<list.size())
		{
			list1.add(list.get(i));   //tweet
			badWords.add(list.get(i+1));
			
			
			review.add(list.get(i+2));
			list2.add(list.get(i+3)); //emotion
			list3.add(list.get(i+4)); //sentiment
			list4.add(list.get(i+5)); //intent
			image_res.add(list.get(i+6));
			i=i+7;
		}
		//model.addAttribute("removeSearch","1");
		model.addAttribute("original", list1);
		model.addAttribute("image_res", image_res);
		model.addAttribute("words", badWords);
		model.addAttribute("toxicity", review);
		model.addAttribute("emotion", list2);
		model.addAttribute("sentiment", list3);
		model.addAttribute("intent", list4);
			
		
		return "fetchInstaTimeline";
	}
	 @RequestMapping("/checkLogin")  
		  public String checkLogin(@RequestParam String email,String pass, Model model)
		  throws java.lang.Exception {
		  
		  Database db = new Database(); 
		  int response = db.checkLogin(email,pass);
		  if(response==1) {
			 
			  return "home";
		  } 
		  else { return "tryAgain";
		  
		  }
		  }
		 
//Cookies Method
	 
	 
	 
	 
	 
	 
	 
	 
//Session methods
		/*
		 * public String login(@RequestParam("email") String
		 * username,@RequestParam("pass") String password,HttpServletRequest
		 * request,Model model) { String user=""; Database db=new Database();
		 * user=db.checkLogin(username, password); if(user==null) {
		 * request.getSession().setAttribute("username", username);
		 * model.addAttribute("email","sessionEmail"); return "home"; } else { return
		 * "tryAgain";
		 * 
		 * } }
		 * 
		 * @RequestMapping("/checkLogout") public String logout(HttpSession session) {
		 * session.removeAttribute("username"); return "redirect:../index"; }
		 */
		/*
		 * protected String login(HttpServletRequest request, HttpServletResponse
		 * response) throws ServletException, IOException { String displaypage="index";
		 * String name = request.getParameter("email"); String password =
		 * request.getParameter("pass"); Database db=new Database(); String
		 * user=db.checkLogin(name, password); if(user!=null) { HttpSession
		 * session=request.getSession(); session.setAttribute("email",name);
		 * session.setAttribute("pass",password); displaypage= "home"; } else {
		 * displaypage= "tryAgain"; } return displaypage; }
		 */
		/*
		 * @RequestMapping("/checkLogout") protected String logout(HttpServletRequest
		 * request, HttpServletResponse response) throws ServletException, IOException {
		 * String s="0"; HttpSession session = request.getSession(false); if (session !=
		 * null) { session.removeAttribute("user"); s= "index";
		 * 
		 * } return s; }
		 */
	
	
	@RequestMapping("/checkUsedResources")
	public String checkUsedResources(Model model) throws java.lang.Exception {
		
		Database db = new Database();
		moderate_content = db.checkResourceUsed("moderateContent");
		parallel_dots = db.checkResourceUsed("ParallelDots");
		return "resourcesUsed";
	}
	
	@RequestMapping("/searchOccurrence")
	
	public String searchOccurrence(@RequestParam String word, Model model) throws java.lang.Exception {
		
	
		ArrayList<String> message = new ArrayList<>();
		ArrayList<String> message1 = new ArrayList<>();
		ArrayList<String> message2 = new ArrayList<>();
		ArrayList<String> statuses = new ArrayList<>();
		
		word= word.toLowerCase();
		TwitterClass f = new TwitterClass();
		statuses = f.getTimeLine();
		int i=0, count = 0 ;
		
		int j=0;
		while(j<statuses.size())
		{
			message.add(statuses.get(j));
			message1.add(statuses.get(j+1));
			message2.add(statuses.get(j+2)+":small");
			j=j+3;
		}
		for(i=0;i<statuses.size();i++)
		{
			if(statuses.get(i).toLowerCase().contains(word))
			{
				statuses.indexOf(word);
				count++;
			}
		}
		
		model.addAttribute("list1", message);
		model.addAttribute("list2", message1);
		model.addAttribute("list3", message2);
		model.addAttribute("Count", "Count found= "+count);
		return "searchOccurrences";
		
	}
	

	
	@RequestMapping("/moderateTwitterText")
	public String moderateTwittertext(Model model,String platform) throws Exception{
	try {
		toxicity.clear();
		image_res.clear();
		toxicity_value.clear();
		intents.clear();
		sentiments.clear();
		emotions.clear();
		moderatedText2.clear();
		ArrayList<String> response = new ArrayList<>();
		ArrayList<String> content = new ArrayList<>();
		ArrayList<String> images = new ArrayList<>();
		ArrayList<String> tweetId = new ArrayList<>();
		ArrayList<String> review = new ArrayList<>();
		
		
		Database db = new Database();
		response = db.getUnmoderatedTweets(platform);
		
		int i=0;
		while(i<response.size())
		{
			content.add(response.get(i));
			images.add(response.get(i+1));
			tweetId.add(response.get(i+2));
			i=i+3;
			
		}
		int countParallel=0, countModerateContent=0, countSightEngine=0;
		
		
		ArrayList<String> child = new ArrayList<>();
		ArrayList<ArrayList<String>> type = new ArrayList<>();
		
		i =0 ; 
		while(i!=content.size())
		{
			String result = "Safe";
			//sentiment analysis
			ParallelDots pd = new ParallelDots();
			String emo= pd.emotionDetect(content.get(i).toString());
			emotions.add(emo);
			String intent = pd.intentAnalysisOld(content.get(i).toString());
			intents.add(intent);
			String sentiment = pd.evalSentiment(content.get(i).toString());
			sentiments.add(sentiment);
			countParallel = countParallel + 3 ; 
			
			//if image present evaluate image
			if(!(images.get(i).toString().equalsIgnoreCase("0")))
			{

				ModerateContent mc = new ModerateContent();
				String url = images.get(i).toString();
				result = mc.moderateImage(url);
				countModerateContent = countModerateContent + 1 ; 
				image_res.add(result);

			}
			else
			{
				image_res.add("No image");
			}
			

			  //text moderate
			  BadWords bd = new BadWords();
				String msg = content.get(i).toString(); 
				child = bd.moderateText(msg, "en");
				ArrayList<String> type_child = new ArrayList<>();
				if(child.get(0).equalsIgnoreCase("No Bad Words") && result.equalsIgnoreCase("Safe"))
				{
					review.add("No");
					type_child.add("Appropriate");
					
				}
				else
				{
					review.add("Yes");
					int iter=1;
					while(iter<child.size())
					{
						type_child.add(child.get(iter).toString());
						iter= iter +2;
					}
					
				}
				type.add(type_child);
				moderatedText2.add(child);			
			
			i++;
		}
		Database db1 = new Database();
		db1.saveAPICalls(countParallel, countModerateContent);
		db1.saveModeratedTweets(moderatedText2, tweetId, intents, emotions, sentiments, review, image_res,platform);
		model.addAttribute("intent", intents);
		model.addAttribute("emotion", emotions);
		model.addAttribute("sentiment", sentiments);
		  model.addAttribute("moderateText",moderatedText2);
			model.addAttribute("original", content);
			model.addAttribute("toxicity", toxicity);
			model.addAttribute("image_res", image_res);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		model.addAttribute("err", "Server overload !");
		if(platform.equals("TwitterResults"))
			return "twitterDashboard";
		else
			return "twitterSearch";
	}
if(platform.equals("TwitterResults"))
	return "twitterDashboard";
else
	return "twitterSearch";
	}
	
	@RequestMapping("/moderateTwitterTextSE")
	public String moderateTwittertextSE(Model model,String platform) throws Exception{
	try {
		toxicity.clear();
		image_res.clear();
		toxicity_value.clear();
		intents.clear();
		sentiments.clear();
		emotions.clear();
		moderatedText2.clear();
		ArrayList<String> response = new ArrayList<>();
		ArrayList<String> content = new ArrayList<>();
		ArrayList<String> images = new ArrayList<>();
		ArrayList<String> tweetId = new ArrayList<>();
		ArrayList<String> review = new ArrayList<>();
		
		
		Database db = new Database();
		response = db.getUnmoderatedTweets(platform);
		
		int i=0;
		while(i<response.size())
		{
			content.add(response.get(i));
			images.add(response.get(i+1));
			tweetId.add(response.get(i+2));
			i=i+3;
			
		}
		int countParallel=0, countModerateContent=0, countSightEngine=0;
		
		
		ArrayList<String> child = new ArrayList<>();
		ArrayList<ArrayList<String>> type = new ArrayList<>();
		
		i =0 ; 
		while(i!=content.size())
		{
			String result = "Safe";
			//sentiment analysis
			ParallelDots pd = new ParallelDots();
			String emo= pd.emotionDetect(content.get(i).toString());
			emotions.add(emo);
			String intent = pd.intentAnalysisOld(content.get(i).toString());
			intents.add(intent);
			String sentiment = pd.evalSentiment(content.get(i).toString());
			sentiments.add(sentiment);
			countParallel = countParallel + 3 ; 
			
			//if image present evaluate image
			if(!(images.get(i).toString().equalsIgnoreCase("0")))
			{

				ModerateContent mc = new ModerateContent();
				String url = images.get(i).toString();
				result = mc.moderateImage(url);
				countModerateContent = countModerateContent + 1 ; 
				image_res.add(result);

			}
			else
			{
				image_res.add("No image");
			}
			

			  //text moderate
			  SightEngine se = new SightEngine();
				String msg = content.get(i).toString(); 
				child = se.textModerate(msg, "en");
				ArrayList<String> type_child = new ArrayList<>();
				if(child.get(0).equalsIgnoreCase("No Bad Words") && result.equalsIgnoreCase("Safe"))
				{
					review.add("No");
					type_child.add("Appropriate");
					
				}
				else
				{
					review.add("Yes");
					int iter=1;
					while(iter<child.size())
					{
						type_child.add(child.get(iter).toString());
						iter= iter +2;
					}
					
				}
				type.add(type_child);
				moderatedText2.add(child);			
			
			i++;
		}
		Database db1 = new Database();
		db1.saveAPICalls(countParallel, countModerateContent);
		db1.saveModeratedTweets(moderatedText2, tweetId, intents, emotions, sentiments, review,image_res,platform);
		model.addAttribute("intent", intents);
		model.addAttribute("emotion", emotions);
		model.addAttribute("sentiment", sentiments);
		  model.addAttribute("moderateText",moderatedText2);
			model.addAttribute("original", listtwo);
			model.addAttribute("toxicity", toxicity);
			model.addAttribute("image_res", image_res);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		model.addAttribute("err", "Server overload !");
		if(platform.equals("TwitterResults"))
			return "twitterDashboard";
		else
			return "twitterSearch";
	}

	if(platform.equals("TwitterResults"))
		return "twitterDashboard";
	else
		return "twitterSearch";
	}
	
	@RequestMapping("/moderateInstaTextSE")
	public String moderateInstatextSE(Model model) throws Exception{
	try {
		toxicity.clear();
		image_res.clear();
		toxicity_value.clear();
		intents.clear();
		sentiments.clear();
		emotions.clear();
		moderatedText2.clear();
		ArrayList<String> response = new ArrayList<>();
		ArrayList<String> content = new ArrayList<>();
		ArrayList<String> images = new ArrayList<>();
		ArrayList<String> postId = new ArrayList<>();
		ArrayList<String> review = new ArrayList<>();
		
		
		Database db = new Database();
		response = db.getUnmoderatedInstaPosts();
		
		int i=0;
		while(i<response.size())
		{
			content.add(response.get(i));
			images.add(response.get(i+1));
			postId.add(response.get(i+2));
			i=i+3;
			
		}
		int countParallel=0, countModerateContent=0, countSightEngine=0;
		
		
		ArrayList<String> child = new ArrayList<>();
		ArrayList<ArrayList<String>> type = new ArrayList<>();
		
		i =0 ; 
		while(i!=content.size())
		{
			String result = "Safe";
			//sentiment analysis
			ParallelDots pd = new ParallelDots();
			String emo= pd.emotionDetect(content.get(i).toString());
			emotions.add(emo);
			String intent = pd.intentAnalysisOld(content.get(i).toString());
			intents.add(intent);
			String sentiment = pd.evalSentiment(content.get(i).toString());
			sentiments.add(sentiment);
			countParallel = countParallel + 3 ; 
			
			//if image present evaluate image
			if(!(images.get(i).toString().equalsIgnoreCase("0")))
			{

				ModerateContent mc = new ModerateContent();
				String url = images.get(i).toString();
				result = mc.moderateImage(url);
				countModerateContent = countModerateContent + 1 ; 
				image_res.add(result);

			}
			else
			{
				image_res.add("No image");
			}
			

			  //text moderate
			  SightEngine se = new SightEngine();
				String msg = content.get(i).toString(); 
				child = se.textModerate(msg, "en");
				ArrayList<String> type_child = new ArrayList<>();
				if(child.get(0).equalsIgnoreCase("No Bad Words") && result.equalsIgnoreCase("Safe"))
				{
					review.add("No");
					type_child.add("Appropriate");
					
				}
				else
				{
					review.add("Yes");
					int iter=1;
					while(iter<child.size())
					{
						type_child.add(child.get(iter).toString());
						iter= iter +2;
					}
					
				}
				type.add(type_child);
				moderatedText2.add(child);			
			
			i++;
		}
		Database db1 = new Database();
		db1.saveAPICalls(countParallel, countModerateContent);
		db1.saveModeratedInstaPosts(moderatedText2, postId, intents, emotions, sentiments, image_res, review);
		model.addAttribute("intent", intents);
		model.addAttribute("emotion", emotions);
		model.addAttribute("sentiment", sentiments);
		  model.addAttribute("moderateText",moderatedText2);
			model.addAttribute("original", listtwo);
			model.addAttribute("toxicity", toxicity);
			model.addAttribute("image_res", image_res);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		model.addAttribute("err", "Server overload !");
		return "fetchInstaTimeline";
	}

		return "fetchInstaTimeline";
	}
	@RequestMapping("/moderateInstaText")
	public String moderateInstatext(Model model) throws Exception{
	try {
		toxicity.clear();
		image_res.clear();
		toxicity_value.clear();
		intents.clear();
		sentiments.clear();
		emotions.clear();
		moderatedText2.clear();
		ArrayList<String> response = new ArrayList<>();
		ArrayList<String> content = new ArrayList<>();
		ArrayList<String> images = new ArrayList<>();
		ArrayList<String> postId = new ArrayList<>();
		ArrayList<String> review = new ArrayList<>();
		
		
		Database db = new Database();
		response = db.getUnmoderatedInstaPosts();
		
		int i=0;
		while(i<response.size())
		{
			content.add(response.get(i));
			images.add(response.get(i+1));
			postId.add(response.get(i+2));
			i=i+3;
			
		}
		int countParallel=0, countModerateContent=0, countSightEngine=0;
		
		
		ArrayList<String> child = new ArrayList<>();
		ArrayList<ArrayList<String>> type = new ArrayList<>();
		
		i =0 ; 
		while(i!=content.size())
		{
			String result = "Safe";
			//sentiment analysis
			ParallelDots pd = new ParallelDots();
			String emo= pd.emotionDetect(content.get(i).toString());
			emotions.add(emo);
			String intent = pd.intentAnalysisOld(content.get(i).toString());
			intents.add(intent);
			String sentiment = pd.evalSentiment(content.get(i).toString());
			sentiments.add(sentiment);
			countParallel = countParallel + 3 ; 
			
			//if image present evaluate image
			if(!(images.get(i).toString().equalsIgnoreCase("0")))
			{

				ModerateContent mc = new ModerateContent();
				String url = images.get(i).toString();
				result = mc.moderateImage(url);
				countModerateContent = countModerateContent + 1 ; 
				image_res.add(result);

			}
			else
			{
				image_res.add("No image");
			}
			

			  //text moderate
			  BadWords bd = new BadWords();
				String msg = content.get(i).toString(); 
				child = bd.moderateText(msg, "en");
				ArrayList<String> type_child = new ArrayList<>();
				if(child.get(0).equalsIgnoreCase("No Bad Words") && result.equalsIgnoreCase("Safe"))
				{
					review.add("No");
					type_child.add("Appropriate");
					
				}
				else
				{
					review.add("Yes");
					int iter=1;
					while(iter<child.size())
					{
						type_child.add(child.get(iter).toString());
						iter= iter +2;
					}
					
				}
				type.add(type_child);
				moderatedText2.add(child);			
			
			i++;
		}
		Database db1 = new Database();
		db1.saveAPICalls(countParallel, countModerateContent);
		db1.saveModeratedInstaPosts(moderatedText2, postId, intents, emotions, sentiments, image_res, review);
		model.addAttribute("original", content);
		model.addAttribute("image_res", image_res);
		model.addAttribute("words", moderatedText2);
		model.addAttribute("toxicity", review);
		model.addAttribute("emotion", emotions);
		model.addAttribute("sentiment", sentiments);
		model.addAttribute("intent", intents);
	}
	catch(Exception e)
	{
		e.printStackTrace();
		model.addAttribute("err", "Server overload !");
		return "fetchInstaTimeline";
	}

		return "fetchInstaTimeline";
	}
	
	@RequestMapping("/search")
	public String searchTwitter(Model model, String query) throws java.lang.Exception {
			if(query.isEmpty())
			{
				model.addAttribute("err", "No String present");
				return "twitterSearch";
			}
			
			list.clear();
			list1.clear();
			list2.clear();
			list3.clear();
			list4.clear();
			TwitterClass f = new TwitterClass();
//			List<String> list=new ArrayList<String>(50);
//			List<String> list1=new ArrayList<String>(15);
//			List<String> list2=new ArrayList<String>(15);
//			List<String> list3=new ArrayList<String>(15);
			list = f.searchtweets(query);
			int i=0;
			if(list.get(0).equalsIgnoreCase("error"))
			{
			model.addAttribute("err", "Server overloaded!");
		    return "twitterSearch";
			}
			while(i<list.size())
			{
				list1.add(list.get(i));
				list2.add(list.get(i+1));
				list3.add(list.get(i+2));
				list4.add(list.get(i+3));
				i=i+4;
			}
			Database db=new Database();
			db.unmoderatedSearchTweets(list1, list2, list3, list4);
			model.addAttribute("message",list1);
			model.addAttribute("message1", list2);
			model.addAttribute("message2", list3);
			model.addAttribute("message3", list4);
			list.clear();
			list1.clear();
			list2.clear();
			list3.clear();
			list4.clear();
			ArrayList<String> images = new ArrayList<>();
			ArrayList<String> badWords = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			list = db.getTweets("TwitterSearchResults");
			i=0;
			while(i<list.size())
			{
				list1.add(list.get(i));   //tweet
				images.add(list.get(i+1));
				badWords.add(list.get(i+2));
				review.add(list.get(i+3));
				list2.add(list.get(i+4)); //emotion
				list3.add(list.get(i+5)); //sentiment
				list4.add(list.get(i+6)); //intent
				i=i+7;
			}
			model.addAttribute("original", list1);
			model.addAttribute("image_res", images);
			model.addAttribute("words", badWords);
			model.addAttribute("toxicity", review);
			model.addAttribute("emotion", list2);
			model.addAttribute("sentiment", list3);
			model.addAttribute("intent", list4);
			
			
			
			return "twitterSearch";
		
		
	}
		
	@RequestMapping("/new")
	public String fetchCommentsUsingVid(Model model,String vid) throws Exception {
			System.out.println("Inside new");
			String num= "5";
			System.out.println(vid);
			if(vid.isEmpty() || num.isEmpty())
			{
				model.addAttribute("message","Fields cannot be empty!");
				return "commentList";
			}
		
			int number = Integer.parseInt(num);
			if(number > 100)
			{
				model.addAttribute("message","Cannot fetch more than 100 comments.");
				return "commentList";
			}
			else if(number<0)
			{
				model.addAttribute("message","Number of comments cannot be below 0.");
				return "commentList";
			}
			ApiExample ap = new ApiExample();
			ArrayList<String> ar = new ArrayList<String>();
			ArrayList<String> list1 = new ArrayList<String>();
			ArrayList<String> list2 = new ArrayList<String>();
			ar =  ap.fetchCommentsUsingVid(vid, number);
			if(ar.size()==1)
			{
				if(ar.get(0).equalsIgnoreCase("error"))
				{
				model.addAttribute("message", "Oh! Your video wasn't found. Please enter a valid URL.");
			    return "commentList";
				}
			}
			int i=0;
			while(i<ar.size())
			{
				list1.add(ar.get(i));
				list2.add(ar.get(i+1));
				i=i+2;
			}
			model.addAttribute("message",list1);
			model.addAttribute("message1", list2);
			ylist1=list1;
			ylist2=list2;
			moderateYoutubeText(model,list1,list2);
			return "commentList";
		}
		
		
		@RequestMapping("/fetchFacebookPagePosts")
	public String fetchFacebookPagePosts(Model model) throws Exception {
			ArrayList<String> posts = new ArrayList<>();
			FacebookHttp face = new FacebookHttp();
			posts = face.getPagePosts();
			if(posts.get(0).toString().equalsIgnoreCase("error"))
			{
				model.addAttribute("err","Server overloaded!");
				return  "fetchFacebookPagePosts";
			}
			else
			{
				System.out.println("reached here");
				//moderateFacebookText(model, posts);
				model.addAttribute("message", posts);
				return "fetchFacebookPagePosts";
				
			}
			
		}
		
	@RequestMapping("/fetchFacebookTimeline")
	public String fetchFacebookTimeline(Model model) throws java.lang.Exception {
			fblist.clear();
			ArrayList<String> id = new ArrayList<>();
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> comments_child = new ArrayList<>();
			ArrayList<ArrayList<String>> comments = new ArrayList<>();
			FacebookHttp fb =new FacebookHttp();
			fblist = fb.getUserTimeline();
			if(fblist.get(0).toString().equalsIgnoreCase("error"))
			{
				
				model.addAttribute("err","Server overloaded!");
				return "fetchFacebookTimeline";
			}
			int i=0;
			Database db = new Database();
			while(i<fblist.size())
			{
				content.add(fblist.get(i));
				id.add(fblist.get(i+1));
				i=i+2;
			}			
			i=0;
			while(i<id.size())
			{
				comments_child =fb.getFacebookComments(id.get(i));
				comments.add(comments_child);
				i++;
			}
				
			db.saveUnmoderatedFacebookPosts(content, id, comments);
			
			list.clear();
			list1.clear();
			list2.clear();
			list3.clear();
			list4.clear();
			ArrayList<String> badWords = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> type = new ArrayList<>();
			list = db.getFbPosts();
			i=0;
			while(i<list.size())
			{
				list1.add(list.get(i));   //post
				badWords.add(list.get(i+1));
				review.add(list.get(i+2));
				list2.add(list.get(i+3)); //emotion
				list3.add(list.get(i+4)); //sentiment
				list4.add(list.get(i+5)); //intent
			type.add(list.get(i+6));
				i=i+7;
			}
			model.addAttribute("original", list1);
			model.addAttribute("words", badWords);
			model.addAttribute("toxicity", review);
			model.addAttribute("emotion", list2);
			model.addAttribute("sentiment", list3);
			model.addAttribute("intent", list4);
			model.addAttribute("type", type);
			
			return "fetchFacebookTimeline";
		}
		
		@RequestMapping("/fetchInstaTimeline")
	public String fetchInstaTimeline(Model model) {
			try {
				Instagram in = new Instagram();
				list.clear();
				list1.clear();
				list2.clear();
				list3.clear();
				list = in.generateTimeLine();
				int i=0;
				/*
				 * if(list.get(0).toString().equalsIgnoreCase("error")) {
				 * model.addAttribute("err","Server Overload"); return "fetchInstaTimeline"; }
				 */
				while(i<list.size())
				{
					list1.add(list.get(i));
					list2.add(list.get(i+1));
					list3.add(list.get(i+2));
					i=i+3;
				}
				model.addAttribute("message",list1);
				model.addAttribute("message2", list2);		
				Database db1 = new Database();
				db1.saveUnmoderatedInstaPosts(list1, list2, list3);
				
				list.clear();
				list1.clear();
				list2.clear();
				list3.clear();
				list4.clear();
		        
				ArrayList<String> badWords = new ArrayList<>();
				ArrayList<String> review = new ArrayList<>();
				ArrayList<String> list5 = new ArrayList<>();
				list = db1.getInstaPosts();
				i=0;
				
				while(i<list.size())
				{
					list1.add(list.get(i));   //post
					badWords.add(list.get(i+1));
					review.add(list.get(i+2));
					list2.add(list.get(i+3)); //emotion
					list3.add(list.get(i+4)); //sentiment
					list4.add(list.get(i+5)); //intent
					list5.add(list.get(i+6));
					i=i+7;
				}
				model.addAttribute("original", list1);
				model.addAttribute("words", badWords);
				model.addAttribute("toxicity", review);
				model.addAttribute("emotion", list2);
				model.addAttribute("sentiment", list3);
				model.addAttribute("intent", list4);
				model.addAttribute("image_res",list5);
				}
				catch(Exception e)
				{
					String s1 = e.getMessage();
					System.out.println(s1);
					String platform="Instagram";
					Database db = new Database();
					db.saveErrors(s1,platform);
					
					model.addAttribute("err", "Server Overload!+");
					
				}			
				return "fetchInstaTimeline";
		}
		
	
		@RequestMapping("/moderateYoutubeText")
	public String moderateYoutubeText(Model model, ArrayList<String> list1, ArrayList<String> list2) throws Exception{
			try {
			ArrayList<String> child = new ArrayList<>();
			
			type.clear();
			emotions.clear();
			sentiments.clear();
			intents.clear();
			moderatedText2.clear();
			toxicity.clear();
			toxicity_value.clear();
			listone.clear();
			listtwo.clear();
			listone=list1;
			listtwo=list2;
		
			
			int i =0 ;  
			while(i<5)
			{
				//sentiment analysis
				ParallelDots pd = new ParallelDots();
				String emo= pd.emotionDetect(list2.get(i).toString());
				emotions.add(emo);
				String intent = pd.intentAnalysisOld(list2.get(i).toString());
				intents.add(intent);
				String sentiment = pd.evalSentiment(list2.get(i).toString());
				sentiments.add(sentiment);
				
				
				//text moderate
				BadWords bd = new BadWords();
				String msg = listtwo.get(i).toString(); 
				child = bd.moderateText(msg, "en");
				ArrayList<String> type_child = new ArrayList<>();
				if(child.get(0).equalsIgnoreCase("No Bad Words"))
				{
					toxicity.add("No");
					type_child.add("Appropriate");
					
				}
				else
				{
					toxicity.add("Yes");
					type_child.add("Inappropriate");
					
				}
				type.add(type_child);
				moderatedText2.add(child);			
				System.out.println("Moderated text2= "+moderatedText2);
				
					i++;
			}


				model.addAttribute("moderateText", moderatedText2);
				model.addAttribute("emotion", emotions);
				model.addAttribute("sentiment", sentiments);
				model.addAttribute("intent", intents);
				model.addAttribute("original", list2);
				model.addAttribute("toxicity", toxicity);
				model.addAttribute("type", type);
			return "commentList";
			}
			catch(Exception e)
			{
				model.addAttribute("err", "Server overloaded");
				return "commentList";
			}
			
		}
		
	@RequestMapping("/moderateFacebookText")
	public String moderateFacebookText(Model model) throws Exception {
			try {
			ArrayList<String> child = new ArrayList<>();
			toxicity.clear();
			emotions.clear();
			sentiments.clear();
			intents.clear();
			toxicity_value.clear();
			listone.clear();
			moderated.clear();
			type.clear();
			int countParallel=0, countModerateContent=0, countSightEngine=0;
			int a=0;String s="";
			ArrayList<String> response = new ArrayList<>();
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> postId = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> stype=new ArrayList<>();
			
			
			Database db = new Database();
			response = db.getUnmoderatedFbPosts();
			
			int i=0;
			while(i<response.size())
			{
				content.add(response.get(i));
				postId.add(response.get(i+1));
				i=i+2;
				
			}
			i =0;
			int count=0 ; 
				while(i!=content.size())
				{	
					//sentiment detection
					ParallelDots pd = new ParallelDots();
					String emo= pd.emotionDetect(content.get(i).toString());
					emotions.add(emo);
					String intent = pd.intentAnalysisOld(content.get(i).toString());
					intents.add(intent);
					String sentiment = pd.evalSentiment(content.get(i).toString());
					sentiments.add(sentiment);
					countParallel = countParallel + 3 ; 
					
					
					BadWords bd = new BadWords();
					String msg = content.get(i).toString();
					child = bd.moderateText(msg, "en");
					ArrayList<String> type_child = new ArrayList<>();
					if(child.get(0).equalsIgnoreCase("No Bad Words"))
					{
						review.add("No");
						//type_child.add("Appropriate");
						s="Appropriate";
					}
					else
					{
						review.add("Yes");
						//type_child.add("Inappropriate");
						s="Inappropriate";
					}
					//type.add(type_child);
					moderated.add(child);		
                     stype.add(s);
					i++;
					count++;
				}
				Database db1 = new Database();
				db1.saveAPICalls(countParallel, countModerateContent);
				db1.saveModeratedFbPosts(moderated, postId, intents, emotions, sentiments, review, stype);
		 
				model.addAttribute("original", content);
				model.addAttribute("type", stype);
				model.addAttribute("words", moderated);
				model.addAttribute("toxicity", review);
				model.addAttribute("emotion", emotions);
				model.addAttribute("sentiment", sentiments);
				model.addAttribute("intent", intents);
				
				
			return "fetchFacebookTimeline";
			}
			catch(Exception e)
			{
				e.printStackTrace();
				model.addAttribute("err", "Server overload !");
				return "fetchFacebookTimeline";
			}
		}

	@RequestMapping("/moderateFacebookTextSE")
	public String moderateFacebookTextSE(Model model) throws Exception {
			try {
			ArrayList<String> child = new ArrayList<>();
			toxicity.clear();
			emotions.clear();
			sentiments.clear();
			intents.clear();
			toxicity_value.clear();
			listone.clear();
			moderated.clear();
			type.clear();
			int countParallel=0, countModerateContent=0, countSightEngine=0;
			int a=0; String s=""; 
			ArrayList<String> response = new ArrayList<>();
			ArrayList<String> content = new ArrayList<>();
			ArrayList<String> postId = new ArrayList<>();
			ArrayList<String> review = new ArrayList<>();
			ArrayList<String> stype=new ArrayList<>();
	 		
			
			
			Database db = new Database();
			response = db.getUnmoderatedFbPosts();
			
			int i=0;
			while(i<response.size())
			{
				content.add(response.get(i));
				postId.add(response.get(i+1));
				i=i+2;
				
			}
			i =0;
			int count=0 ; 
				while(i!=content.size())
				{	
					//sentiment detection
					ParallelDots pd = new ParallelDots();
					String emo= pd.emotionDetect(content.get(i).toString());
					emotions.add(emo);
					String intent = pd.intentAnalysisOld(content.get(i).toString());
					intents.add(intent);
					String sentiment = pd.evalSentiment(content.get(i).toString());
					sentiments.add(sentiment);
					countParallel = countParallel + 3 ; 
					
					
					SightEngine se = new SightEngine();
					String msg = content.get(i).toString();
					child = se.textModerate(msg, "en");
					ArrayList<String> type_child = new ArrayList<>();
					if(child.get(0).equalsIgnoreCase("No Bad Words"))
					{
						review.add("No");
						//type_child.add("Appropriate");
						s="Appropriate";
					}
					else
					{
						review.add("Yes");
						//type_child.add("Inappropriate");
						s="Inappropriate";
						
					}
					stype.add(s);
				//	type.add(type_child);
			moderated.add(child);		
					i++;
					count++;
				}
				Database db1 = new Database();
				db1.saveAPICalls(countParallel, countModerateContent);
				db1.saveModeratedFbPosts(moderated, postId, intents, emotions, sentiments, review, stype);
		 
			model.addAttribute("moderated", moderated);
				model.addAttribute("type", type);
				model.addAttribute("original", listone);
				model.addAttribute("toxicity", toxicity);
				model.addAttribute("intent", intents);
				model.addAttribute("emotion", emotions);
				model.addAttribute("sentiment", sentiments);
				
			return "fetchFacebookTimeline";
			}
			catch(Exception e)
			{
				model.addAttribute("err", "Server overload !");
				return "fetchFacebookTimeline";
			}
		}
	@RequestMapping("/fetchYoutubeVideos")
	public String fetchYoutubeVideoUsingChannelID(Model model, String url){
			try {
			ArrayList<String> ar = new ArrayList<>();
			ArrayList<String> video = new ArrayList<>();
			ArrayList<String> video1 = new ArrayList<>();
			
			if(url.isEmpty())
			{
				model.addAttribute("message", "Empty String");
				return "fetchYoutubeVideos";
			}
			 url = url.trim();
			 ApiExample ae = new ApiExample();
			 String cid = ae.getChannelID(url);
			 
			 String uploadID = ae.fetchUploadIdUsingChannelId(cid, 10);
			 ar = ae.fetchVidsUsingUploadID(uploadID);
			 int i=0;
			 while(i<ar.size())
			 {
				 video.add(ar.get(i).toString());
				 video1.add(ar.get(i+1).toString());
				 i+=2;
			 }
			 fetchCommentsUsingVid(model,video1.get(0).toString());
			 
			 return "fetchYoutubeVideos";
			}
			catch(Exception e)
			{
				
				return "fetchYoutubeVideos";
			}
		}
		

		
		@RequestMapping("/fetchDataUsingFiltersYoutube")
	public String fetchDataUsingFiltersYoutube(Model model, String intent, String sentiment, String start, String end, String review) throws ParseException, IOException, org.json.simple.parser.ParseException{
			try {
			JSONArray ar = new JSONArray();
			Database db = new Database();
			ar = db.fetchDataUsingFilterPosts(sentiment, intent, "YoutubeResults", review);
			if(!(start.isEmpty() && end.isEmpty()))
			{
				ar=db.getRange(start, end, ar);

			}
			
			createYoutubeGraph(model,ar);
			return "youTubeCharts";
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return "youTubeCharts";
			}
		}
		
		@RequestMapping("/fetchDataUsingFiltersFacebook")
	public String fetchDataUsingFiltersFacebook(Model model, String intent, String sentiment, String review, String start, String end) throws ParseException, IOException, org.json.simple.parser.ParseException{
			try {
			JSONArray ar = new JSONArray();
			Database db = new Database();
			ar = db.fetchDataUsingFilterPosts(sentiment, intent, "FacebookResults", review);
			if(!(start.isEmpty() && end.isEmpty()))
			{
				ar=db.getRange(start, end, ar);

			}
			createFaceBookGraph(model,ar);
			return "facebookCharts";
			}
			catch(Exception e)
			{
				return "facebookCharts";
			}
		}
		
		@RequestMapping("/fetchDataUsingFiltersTwitter")
	public String fetchDataUsingFiltersTwitter(Model model, String intent, String sentiment, String review,String start, String end ) throws ParseException, IOException, org.json.simple.parser.ParseException{
			try {
			JSONArray ar = new JSONArray();
			Database db = new Database();
			
			ar = db.fetchDataUsingFilterPosts(sentiment, intent, "TwitterSearchResults", review);
			
			if(!(start.isEmpty() && end.isEmpty()))
			{
				ar=db.getRange(start, end, ar);
				System.out.println("length of arr2"+ar.length());
			}
			
			createTwitterGraph(model,ar);
			return "twitterCharts";
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return "twitterCharts";
			}
		} 
		
		
		@RequestMapping("/fetchDataUsingFiltersNoonTwitter")
		public String fetchDataUsingFiltersNoonTwitter(Model model, String intent, String sentiment, String review,String start, String end ) throws ParseException, IOException, org.json.simple.parser.ParseException{
				try {
				JSONArray ar = new JSONArray();
				Database db = new Database();
				list.clear();
         		list1.clear();
         		list2.clear();
         		list3.clear();
         		list4.clear();
         		
         		ArrayList<String> images = new ArrayList<>();
         		ArrayList<String> badWords = new ArrayList<>();
         		ArrayList<String> reviewList = new ArrayList<>();
				ar = db.fetchDataUsingFilterPosts(sentiment, intent, "TwitterSearchResults", review);
				
				if(!(start.isEmpty() && end.isEmpty()))
				{
					ar=db.getRange(start, end, ar);
					System.out.println("length of arr2"+ar.length());
				}
				
             int i=0;
             if(ar.length()>1)
             {
             while(i<ar.length())
             {
            	
            	JSONObject element= (JSONObject) ar.get(i);
            	 list1.add(element.getString("Tweets"));
            	 images.add(element.getString("Images"));
            	 badWords.add(element.getString("Badwords"));
            	 reviewList.add(element.getString("Review"));
            	 list2.add(element.getString("Emotion"));
            	 list3.add(element.getString("Sentiment"));
            	 list4.add(element.getString("Intent"));
            	 i++;
            	 
             }
             }
             else {
            	JSONObject element =(JSONObject) ar.get(0);
            	if(element.has("responses"))
            	{
            		model.addAttribute("removeSearch", "1");
            	}
            	 
             }
             
         		model.addAttribute("original", list1);
         		model.addAttribute("image_res", images);
         		model.addAttribute("words", badWords);
         		model.addAttribute("toxicity", reviewList);
         		model.addAttribute("emotion", list2);
         		model.addAttribute("sentiment", list3);
         		model.addAttribute("intent", list4);
         		model.addAttribute("removeSearch","1");
            
             
             
            
				return "twitterSearch";
				}
				
				catch(Exception e)
				{
					e.printStackTrace();
					model.addAttribute("removeSearch", "1");
					return "twitterSearch";
				}
			} 
		
		@RequestMapping("/fetchDataUsingFiltersServices")
		public String fetchDataUsingFiltersResources(Model model, String start, String end) throws ParseException, IOException, org.json.simple.parser.ParseException{
				try {
				JSONArray ar = new JSONArray();
				JSONArray ar1 = new JSONArray();
				Database db = new Database();
				ar = db.checkResourceUsed("ModerateContent");
				ar1 = db.checkResourceUsed("ParallelDots");
				
				System.out.println("arrrr="+ar);
				System.out.println("arrrr="+ar1);
				if(!(start.isEmpty() && end.isEmpty()))
				{
					ar=db.getRange(start, end, ar);
				}
				System.out.println("length of ar = "+ar.length());
				
				if(!(start.isEmpty() && end.isEmpty()))
				{
					ar1=db.getRange(start, end, ar1);
			
				}
				System.out.println("length of ar1 = "+ar1.length());
				createUsedResourcesGraph(model,ar,ar1);
				return "resourcesUsed";
				}
				catch(Exception e)
				{
					e.printStackTrace();
					return "resourcesUsed";
				}
			} 
		
		@RequestMapping("/fetchDataUsingFiltersInsta")
	public String fetchDataUsingFiltersInstagram(Model model, String intent, String sentiment, String review) throws ParseException, IOException, org.json.simple.parser.ParseException{
			
			JSONArray ar = new JSONArray();
			Database db = new Database();
			ar = db.fetchDataUsingFilterPosts(sentiment, intent, "InstagramResults",review);
			createInstagramGraph(model,ar);
			return "instagramCharts";
		}

		@RequestMapping("/fetchDataUsingFiltersCommandCenter")
	public String fetchDataUsingFiltersCommandCenter(Model model, String intent, String sentiment,String review, String start, String end) throws ParseException, IOException, org.json.simple.parser.ParseException{
			try {
				System.out.println(start);
			JSONArray twitterData = new JSONArray();
			JSONArray facebookData = new JSONArray();
			JSONArray youtubeData = new JSONArray();
			Database db = new Database();
			twitterData = db.fetchDataUsingFilterPosts(sentiment, intent,"TwitterSearchResults", review);
			facebookData = db.fetchDataUsingFilterPosts(sentiment, intent, "FacebookResults", review);
			youtubeData = db.fetchDataUsingFilterPosts(sentiment, intent, "YoutubeResults", review);
			System.out.println("data0= "+twitterData);

			if(!(start.isEmpty() && end.isEmpty()))
			{
				twitterData = db.getRange(start, end, twitterData);
				//facebookData = db.getRange(start, end, facebookData);
				//youtubeData = db.getRange(start, end, youtubeData);
			}
			System.out.println("data="+twitterData);
			//getFacebookcc(model, facebookData);
			getTwittercc(model, twitterData);
			//getYoutubecc(model, youtubeData);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return "commandCenter";
			}
			return "commandCenter";
		}
		
		@RequestMapping("/saveResultsTwitter")
	public String saveResultsTwitter(Model model) throws Exception{
			
			int response;
			Database db = new Database();
			response = db.saveTwitterResults(list2, moderatedText2, intents, sentiments, emotions, image_res, toxicity, "autodesk");
			if(response==1)
			{
				populateCommandCenter(model);	
				model.addAttribute("response","Save Successful.");
			}
			else
			{
				populateCommandCenter(model);
				model.addAttribute("response","Not saved");
			}
			return "commandCenter";
		}
		
		@RequestMapping("/saveResultsFacebook")
	public String saveResultsFacebook(Model model) throws Exception{
			
			int response;
			Database db = new Database();
			response = db.saveFacebookResults(listone, moderated, intents, sentiments, emotions, toxicity,type, "autodesk-forum");
			if(response==1)
			{
				populateCommandCenter(model);	
				model.addAttribute("response","Save Successful.");
			}
			else
			{
				populateCommandCenter(model);
				model.addAttribute("response","Not saved");
			}
			return "commandCenter";
		}
		
		@RequestMapping("/saveResultsYoutube")
	public String saveResultsYoutube(Model model) throws Exception{
			
			int response;
			Database db = new Database();
			response = db.saveYoutubeResults(listone, listtwo, moderatedText2, intents, sentiments, emotions, toxicity, type, "ck");
			if(response==1)
			{
				populateCommandCenter(model);	
				model.addAttribute("response","Save Successful.");
			}
			else
			{
				populateCommandCenter(model);
				model.addAttribute("response","Not saved");
			}
			return "commandCenter";
		}
		
		@RequestMapping("/saveResultsInstagram")
		public String saveResultsInstagram(Model model) throws Exception{
				
				int response;
				Database db = new Database();
				response = db.saveInstagramResults(list1, moderatedText2, intents, sentiments, emotions, image_res, toxicity, "autodesk");
				if(response==1)
				{
					populateCommandCenter(model);	
					model.addAttribute("response","Save Successful.");
				}
				else
				{
					populateCommandCenter(model);
					model.addAttribute("response","Not saved");
				}
				return "commandCenter";
			}
	
}

package moderation;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

//import org.apache.catalina.User;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Database {

	public int  checkLogin(String user, String password) {
		int response = 0;
		
		try {
			
		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("Users");

		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {

			if (document.getString("user").equals(user) && document.getString("password").equals(password)) {
				response =1;
				
				
			}

		}
		mongo.close();
		}
		catch(Exception e)
		{
			
			response = -1;
		}
		return response;
	}
	
	public JSONArray readcontentfromJSON() {
		JSONArray response = null;
		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader("C:\\json/dummy-data.json"));
			org.json.simple.JSONArray ar = (org.json.simple.JSONArray) obj;
			String s = ar.toString();
			response = new JSONArray(s);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	public JSONArray readinstafromJSON() {
		JSONArray response = null;
		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader("C:\\json/instagram.json"));
			org.json.simple.JSONArray ar = (org.json.simple.JSONArray) obj;
			String s = ar.toString();
			response = new JSONArray(s);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	public HashMap<String, Integer> getBadWordCount(String platform) {

		JSONArray array = new JSONArray();
		HashMap<String,Integer> wordCount = new HashMap<>();
		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection(platform);
		ArrayList<String> words = new ArrayList<>();
		FindIterable<Document> iterDoc = collection.find();
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {

			JSONObject data = new JSONObject();
			String s = document.getString("bad words");
			s= s.replace("[", "");
			s= s.replace("]", "");
			String[] stringarr = s.split(",");
			for(String a: stringarr)
			{
				a= a.trim();
				words.add(a);
			}
		}
		int i=0; 
		while(i<words.size())
		{
			if(wordCount.containsKey(words.get(i)))
			{
				System.out.println("entered");
				int val = wordCount.get(words.get(i));
				val = val + 1; 
				wordCount.put(words.get(i), val);
			}
			else
			{
				wordCount.put(words.get(i), 1);
			}
			i++;
		}
		if(wordCount.containsKey("No Bad Words"))
		{
			wordCount.remove("No Bad Words");
		}
		if(wordCount.containsKey("No Bad Word"))
		{
			wordCount.remove("No Bad Word");
		}
		mongo.close();
		return wordCount;

	}
	
	public int saveTwitterResults(ArrayList<String> original, ArrayList<ArrayList<String>> moderateText,
			ArrayList<String> intent, ArrayList<String> sentiment, ArrayList<String> emotion,
			ArrayList<String> image_res, ArrayList<String> toxicity, String company) {
		try {
			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("ContentModeration");
			MongoCollection<Document> collection = db.getCollection("TwitterResults");

			int i = 0;
			System.out.println(original.size());
			while (i < original.size()) {
				Document doc = new Document();
				doc.append("tweet", original.get(i).toString());
				doc.append("bad words", moderateText.get(i).toString());
				doc.append("intent", intent.get(i).toString());
				doc.append("sentiment", sentiment.get(i).toString());
				doc.append("emotion", emotion.get(i).toString());
				doc.append("image", image_res.get(i).toString());
				doc.append("review", toxicity.get(i).toString());
				doc.append("company", company);
				collection.insertOne(doc);
				i++;
			}
			mongo.close();
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}
	public int unmoderatedTweets(ArrayList<String> name, ArrayList<String> content,
			ArrayList<String> image, ArrayList<String> tweetId) {
		try {
			ArrayList<String> id=new ArrayList<String>();
			
			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection("TwitterResults");
            Database db1=new Database();
            id=db1.checkDuplicate("TwitterResults");
			int i = 0;
			
			while (i < name.size()) {
				if(!(id.contains(tweetId.get(i))))
				{
				Document doc = new Document();
				doc.append("tweet", content.get(i).toString());
				doc.append("image", image.get(i).toString());
				doc.append("tweetId", tweetId.get(i).toString());
				doc.append("status", "No");
				collection.insertOne(doc);
				}
				
				i++;
			}
			mongo.close();
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}
	
	
	
	public int unmoderatedSearchTweets(ArrayList<String> name, ArrayList<String> content,
			ArrayList<String> image, ArrayList<String> tweetId) {
		try {
			ArrayList<String> id=new ArrayList<String>();
			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection("TwitterSearchResults");
			Database db1=new Database();
			Date d=new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
            id=db1.checkDuplicate("TwitterSearchResults");
			int i = 0;
			while (i < name.size()) {
				if(!(id.contains(tweetId.get(i))))
				{
				Document doc = new Document();
				doc.append("tweet", content.get(i).toString());
				doc.append("image", image.get(i).toString());
				doc.append("tweetId", tweetId.get(i).toString());
				doc.append("status", "No");
				doc.append("date",sdf.format(d));
				collection.insertOne(doc);
				}
				i++;
			}
			mongo.close();
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}
	
	public int saveUnmoderatedFacebookPosts(ArrayList<String> content, ArrayList<String> postId, ArrayList<ArrayList<String>> comment) {
		try {
			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection("FacebookResults");

			int i = 0;
			while (i < content.size()) {
				Document doc = new Document();
				doc.append("post", content.get(i).toString());
				doc.append("postId", postId.get(i).toString());
				doc.append("comments", comment.get(i).toString());
				doc.append("status", "No");
				collection.insertOne(doc);
				i++;
			}
			mongo.close();
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}
	
	public int saveUnmoderatedInstaPosts(ArrayList<String> content, ArrayList<String> postId, ArrayList<String> image ) {
		try {
			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection("InstagramResults");
			System.out.println("imagelist"+image);
			int i = 0;
			while (i < content.size()) {
				Document doc = new Document();
				doc.append("post", content.get(i).toString());
				doc.append("postId", postId.get(i).toString());
				doc.append("image", image.get(i).toString());
				doc.append("status", "No");
				collection.insertOne(doc);
				i++;
			}
			mongo.close();
			return 1;
		} catch (Exception e) {
			
			e.printStackTrace();
			return -1;
		}

	}
	public ArrayList<String> getUnmoderatedTweets(String platform) {
		ArrayList<String> tweets = new ArrayList<>();
		try {
			

			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection(platform);

			FindIterable<Document> iterDoc = collection.find();
			List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

			for (Document document : documents) {

				if (document.getString("status").equalsIgnoreCase("No")) {
					
					tweets.add(document.getString("tweet"));
					tweets.add(document.getString("image"));
					tweets.add(document.getString("tweetId"));
					
				}

			}
			System.out.println(tweets);
			mongo.close();
			return tweets;

		}
		catch(Exception e)
		{
			return tweets;
		}
	}
	
	public ArrayList<String> getTweets(String platform) {
		ArrayList<String> tweets = new ArrayList<>();
		try {
			

			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection(platform);

			FindIterable<Document> iterDoc = collection.find();
			List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

			for (Document document : documents) {
					
					tweets.add(document.getString("tweet"));
					if(document.containsKey("image result"))
						tweets.add(document.getString("image result"));
						else
						tweets.add("Not moderated");
					
					if(document.containsKey("badwords"))
						tweets.add(document.getString("badwords"));
						else
						tweets.add("Not moderated");
						if(document.containsKey("review"))
						tweets.add(document.getString("review"));
					else
						tweets.add("Processing");
					if(document.containsKey("emotion"))
						tweets.add(document.getString("emotion"));
					else
						tweets.add("Emotion to be accessed");
					
					if(document.containsKey("sentiment"))
						tweets.add(document.getString("sentiment"));
					else
						tweets.add("Sentiment to be accessed");
					
					if(document.containsKey("intent"))
						tweets.add(document.getString("intent"));
					else
						tweets.add("Intent to be accessed");

			}
			mongo.close();
			System.out.println(tweets);
			return tweets;

		}
		catch(Exception e)
		{
			return tweets;
		}
	}
	
	public ArrayList<String> getFbPosts() {
		ArrayList<String> tweets = new ArrayList<>();
		try {
			

			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection("FacebookResults");

			FindIterable<Document> iterDoc = collection.find();
			List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

			for (Document document : documents) {
					
					tweets.add(document.getString("comments"));
					if(document.containsKey("badwords"))
						tweets.add(document.getString("badwords"));
						else
						tweets.add("Not moderated");
						if(document.containsKey("review"))
						tweets.add(document.getString("review"));
					else
						tweets.add("Processing");
					if(document.containsKey("emotion"))
						tweets.add(document.getString("emotion"));
					else
						tweets.add("Emotion to be accessed");
					
					if(document.containsKey("sentiment"))
						tweets.add(document.getString("sentiment"));
					else
						tweets.add("Sentiment to be accessed");
					
					if(document.containsKey("intent"))
						tweets.add(document.getString("intent"));
					else
						tweets.add("Intent to be accessed");
					if(document.containsKey("type"))
						tweets.add(document.getString("type"));
					else
						tweets.add("Type to be accessed");

			}
			mongo.close();
			System.out.println(tweets);
			return tweets;

		}
		catch(Exception e)
		{
			return tweets;
		}
	}
	
	public ArrayList<String> getInstaPosts() {
		ArrayList<String> tweets = new ArrayList<>();
		try {
			

			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection("InstagramResults");

			FindIterable<Document> iterDoc = collection.find();
			List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

			for (Document document : documents) {
					
					tweets.add(document.getString("post"));
					if(document.containsKey("badwords"))
						tweets.add(document.getString("badwords"));
						else
						tweets.add("Not moderated");
						if(document.containsKey("review"))
						tweets.add(document.getString("review"));
					else
						tweets.add("Processing");
					if(document.containsKey("emotion"))
						tweets.add(document.getString("emotion"));
					else
						tweets.add("Emotion to be accessed");
					
					if(document.containsKey("sentiment"))
						tweets.add(document.getString("sentiment"));
					else
						tweets.add("Sentiment to be accessed");
					
					if(document.containsKey("intent"))
						tweets.add(document.getString("intent"));
					else
						tweets.add("Intent to be accessed");
					
					if(document.containsKey("image result"))
						tweets.add(document.getString("image result"));
					else
						tweets.add("Image to be accessed");

			}
			mongo.close();
			System.out.println(tweets);
			return tweets;

		}
		catch(Exception e)
		{
			return tweets;
		}
	}

	public ArrayList<String> getErrors() {
		ArrayList<String> errors = new ArrayList<>();
		try {
			
			//SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy ");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection("Errors");
			List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

			for (Document document : documents) {
					errors.add(document.getString("Description"));
					Date d = document.getDate("date");
					errors.add(sdf.format(d));
					errors.add(document.getString("Platform"));
					

			}
			mongo.close();
			System.out.println(errors);
			return errors;

		}
		catch(Exception e)
		{
			return errors;
		}
	}
	public ArrayList<String> getUnmoderatedInstaPosts() {
		ArrayList<String> posts = new ArrayList<>();
		try {
			

			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection("InstagramResults");

			FindIterable<Document> iterDoc = collection.find();
			List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

			for (Document document : documents) {

				if (document.getString("status").equalsIgnoreCase("No")) {
					
					posts.add(document.getString("post"));
					posts.add(document.getString("image"));
					posts.add(document.getString("postId"));
					
				}

			}
			System.out.println(posts);
			mongo.close();
			return posts;

		}
		catch(Exception e)
		{
			return posts;
		}
	}
	public ArrayList<String> getUnmoderatedFbPosts() {
		ArrayList<String> posts = new ArrayList<>();
		try {
			

			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection("FacebookResults");

			FindIterable<Document> iterDoc = collection.find();
			List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

			for (Document document : documents) {

				if (document.getString("status").equalsIgnoreCase("No")) {
					
					posts.add(document.getString("comments"));
					posts.add(document.getString("postId"));
					
				}

			}
			mongo.close();
			return posts;

		}
		catch(Exception e)
		{
			return posts;
		}
	}
	
	public ArrayList<String> getUsersFromDB() {
		ArrayList<String> users = new ArrayList<>();
		try {
			

			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("CM");
			MongoCollection<Document> collection = db.getCollection("Users");

			FindIterable<Document> iterDoc = collection.find();
			List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

			for (Document document : documents) {

				 {
					users.add(document.getString("first name"));
					users.add(document.getString("email"));
					users.add(document.getString("last name"));
					
				}

			}
			mongo.close();
			return users;

		}
		catch(Exception e)
		{
			return users;
		}
	}
	
	public int saveModeratedTweets(ArrayList<ArrayList<String>> badwords, ArrayList<String> tweetId, ArrayList<String> intent, ArrayList<String> emotion, ArrayList<String> sentiment, ArrayList<String> review, ArrayList<String> image_res,String platform) {
		try {
		
		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("CM");
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		int i=0;
		while(i<tweetId.size())
		{
		BasicDBObject query = new BasicDBObject();
		query.put("tweetId", tweetId.get(i).toString()); // (1)

		BasicDBObject newDocument = new BasicDBObject();
		newDocument.put("status", "Yes"); // (2)
		newDocument.put("badwords", badwords.get(i).toString());
		newDocument.put("emotion", emotion.get(i));
		newDocument.put("sentiment", sentiment.get(i));
		newDocument.put("intent", intent.get(i));
		newDocument.put("review", review.get(i));
		newDocument.put("image result", image_res.get(i));
		
		
		BasicDBObject updateObject = new BasicDBObject();
		updateObject.put("$set", newDocument); // (3)
		db.getCollection(platform).updateMany(query, updateObject); // (4)
		i++;
		}
		mongo.close();
		return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0 ;
		}
	}
	
	public int saveModeratedFbPosts(ArrayList<ArrayList<String>> badwords, ArrayList<String> postId, ArrayList<String> intent, ArrayList<String> emotion, ArrayList<String> sentiment, ArrayList<String> review, ArrayList<String> stype) {
		try {
		
		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("CM");
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		int i=0;
		while(i<postId.size())
		{
		BasicDBObject query = new BasicDBObject();
		query.put("postId", postId.get(i).toString()); // (1)

		BasicDBObject newDocument = new BasicDBObject();
		newDocument.put("status", "Yes"); // (2)
		newDocument.put("badwords", badwords.get(i).toString());
		newDocument.put("emotion", emotion.get(i));
		newDocument.put("sentiment", sentiment.get(i));
		newDocument.put("intent", intent.get(i));
		newDocument.put("review", review.get(i));
		newDocument.put("type", stype.get(i));
		
		BasicDBObject updateObject = new BasicDBObject();
		updateObject.put("$set", newDocument); // (3)
		db.getCollection("FacebookResults").updateMany(query, updateObject); // (4)
		i++;
		}
		mongo.close();
		return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0 ;
		}
	}

	public int saveModeratedInstaPosts(ArrayList<ArrayList<String>> badwords, ArrayList<String> postId, ArrayList<String> intent, ArrayList<String> emotion, ArrayList<String> sentiment, ArrayList<String> image, ArrayList<String> review) {
		try {
		
		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("CM");
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		int i=0;
		while(i<postId.size())
		{
		BasicDBObject query = new BasicDBObject();
		query.put("postId", postId.get(i).toString()); // (1)

		BasicDBObject newDocument = new BasicDBObject();
		newDocument.put("status", "Yes"); // (2)
		newDocument.put("badwords", badwords.get(i).toString());
		newDocument.put("image result", image.get(i).toString());
		newDocument.put("emotion", emotion.get(i));
		newDocument.put("sentiment", sentiment.get(i));
		newDocument.put("intent", intent.get(i));
		newDocument.put("review", review.get(i));
		
		BasicDBObject updateObject = new BasicDBObject();
		updateObject.put("$set", newDocument); // (3)
		db.getCollection("InstagramResults").updateMany(query, updateObject); // (4)
		i++;
		}
		mongo.close();
		return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0 ;
		}
	}

	public int saveInstagramResults(ArrayList<String> original, ArrayList<ArrayList<String>> moderateText,
			ArrayList<String> intent, ArrayList<String> sentiment, ArrayList<String> emotion,
			ArrayList<String> image_res, ArrayList<String> toxicity, String company) {
		try {
			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("ContentModeration");
			MongoCollection<Document> collection = db.getCollection("InstagramResults");

			int i = 0;
			System.out.println(original.size());
			while (i < original.size()) {
				Document doc = new Document();
				doc.append("post", original.get(i).toString());
				doc.append("bad words", moderateText.get(i).toString());
				doc.append("intent", intent.get(i).toString());
				doc.append("sentiment", sentiment.get(i).toString());
				doc.append("emotion", emotion.get(i).toString());
				doc.append("image", image_res.get(i).toString());
				doc.append("review", toxicity.get(i).toString());
				doc.append("company", company);
				collection.insertOne(doc);
				i++;
			}
			mongo.close();
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}

	public int saveFacebookResults(ArrayList<String> original, ArrayList<ArrayList<String>> moderateText,
			ArrayList<String> intent, ArrayList<String> sentiment, ArrayList<String> emotion,
			ArrayList<String> toxicity, ArrayList<ArrayList<String>> type, String company) {
		try {
			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("ContentModeration");
			MongoCollection<Document> collection = db.getCollection("FacebookResults");
			int i = 0;
			System.out.println(original.size());
			while (i < original.size()) {
				Document doc = new Document();
				doc.append("post", original.get(i).toString());
				doc.append("bad words", moderateText.get(i).toString());
				doc.append("intent", intent.get(i).toString());
				doc.append("sentiment", sentiment.get(i).toString());
				doc.append("emotion", emotion.get(i).toString());
				doc.append("review", toxicity.get(i).toString());
				doc.append("type", type.get(i).toString());
				doc.append("company", company);
				collection.insertOne(doc);
				i++;
			}
			mongo.close();
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}

	public int saveYoutubeResults(ArrayList<String> sender, ArrayList<String> original,
			ArrayList<ArrayList<String>> moderateText, ArrayList<String> intent, ArrayList<String> sentiment,
			ArrayList<String> emotion, ArrayList<String> toxicity, ArrayList<ArrayList<String>> type, String company) {
		try {
			MongoClient mongo = new MongoClient("localhost", 27017);
			MongoDatabase db = mongo.getDatabase("ContentModeration");
			MongoCollection<Document> collection = db.getCollection("YoutubeResults");
			int i = 0;
			System.out.println(original.size());
			while (i < original.size()) {
				Document doc = new Document();
				doc.append("Name", sender.get(i).toString());
				doc.append("Comment", original.get(i).toString());
				doc.append("bad words", moderateText.get(i).toString());
				doc.append("intent", intent.get(i).toString());
				doc.append("sentiment", sentiment.get(i).toString());
				doc.append("emotion", emotion.get(i).toString());
				doc.append("review", toxicity.get(i).toString());
				doc.append("type", type.get(i).toString());
				doc.append("company", company);
				collection.insertOne(doc);
				i++;
			}
			mongo.close();
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}

	}

	public JSONArray readImagesfromJSON() {
		JSONArray response = null;
		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader("C:\\json/dummy-images-data.json"));
			org.json.simple.JSONArray ar = (org.json.simple.JSONArray) obj;
			String s = ar.toString();
			response = new JSONArray(s);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}

	public int saveImageToDB(String result, String url) {

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("Images");
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		int i = 0;

		Document doc = new Document();
		doc.append("url", url);
		doc.append("category", result);
		if (!(result.toString().equalsIgnoreCase("Safe"))) {
			doc.append("review", "yes");
		} else {
			doc.append("review", "no");
		}
		doc.append("date", sdf.format(d));
		collection.insertOne(doc);
		i++;

		mongo.close();
		return 1;

	}
	public int saveAPICalls(int countParallel, int countModerateContent) {

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("Resources");
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		Document doc = new Document();
		doc.append("service", "ParallelDots");
		doc.append("count", countParallel);
		doc.append("date", sdf.format(d));
		collection.insertOne(doc);
		
		
		Document doc2 = new Document();
		doc2.append("service", "ModerateContent");
		doc2.append("count", countModerateContent);
		doc2.append("date", sdf.format(d));
		collection.insertOne(doc2);

		mongo.close();
		return 1;

	}
	
	public int saveUser(String first, String last, String email) {

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("CM");
		MongoCollection<Document> collection = db.getCollection("Users");
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());
		System.out.println("size="+documents.size());
		if (documents.size()==0)
		{
			Document doc = new Document();
			doc.append("first name", first);
			doc.append("last name", last);
			doc.append("email", email);
			collection.insertOne(doc);
			
		
		mongo.close();
		return 1;
		}
		for (Document document : documents) {
			
				if(document.getString("email").equalsIgnoreCase(email))
				{
					mongo.close();
					return -1;
				}
		}
		
			Document doc = new Document();
			doc.append("first name", first);
			doc.append("last name", last);
			doc.append("email", email);
			collection.insertOne(doc);
			
		
		mongo.close();
		return 1;

	}
	

	  public int  deleteUser(String email) { 
	  MongoClient mongo = new MongoClient("localhost", 27017);
	  MongoDatabase db = mongo.getDatabase("CM");
	  MongoCollection<Document> collection = db.getCollection("Users");
	  List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());
	  for(Document document: documents)
	  {
		  if(document.getString("email").equalsIgnoreCase(email))
		  {
			  BasicDBObject theQuery = new BasicDBObject();
			  theQuery.put("email", email);
			  collection.deleteMany(theQuery);
			  return 1;
		  }
	  }
	  return -1;
	  }
	
	
	  public ArrayList<String> checkDuplicate(String platform)
		{
		  String parameter="";
		  if(platform.equalsIgnoreCase("TwitterResults") || platform.equalsIgnoreCase("TwitterSearchResults"))
		  {
		     parameter="tweetId";
		     
		  }
		  
		  else
		  {
			  parameter="postId";
		  }
		  
		  ArrayList<String> ids = new ArrayList<>();
			try {
				MongoClient mongo = new MongoClient("localhost", 27017);
				MongoDatabase db = mongo.getDatabase("CM");
				MongoCollection<Document> collection = db.getCollection(platform);

				FindIterable<Document> iterDoc = collection.find();
				List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

				for (Document document : documents) {
						
						ids.add(document.getString(parameter));
					
				}
				mongo.close();
				return ids;

			}
			catch(Exception e)
			{
				return ids;
			}	
		}
	  
		

	public int saveErrors(String err,String platform) {

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("CM");
		MongoCollection<Document> collection = db.getCollection("Errors");
		Date d = new Date();

		Document doc = new Document();
		doc.append("Description", err);
		doc.append("Platform", platform);
		doc.append("date", d);
		collection.insertOne(doc);

		mongo.close();
		return 1;

	}

	public int saveDB(ArrayList<String> name, ArrayList<String> content, ArrayList<Double> toxicity) {

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("Tweets");
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		int i = 0;
		while (i < name.size()) {
			Document doc = new Document();
			doc.append("name", name.get(i).toString());
			doc.append("content", content.get(i).toString());
			doc.append("toxicity", toxicity.get(i).toString());
			doc.append("date", sdf.format(d));
			collection.insertOne(doc);
			i++;
		}
		mongo.close();
		return 1;

	}

	public JSONArray getFbPostsfromDB() {

		JSONArray array = new JSONArray();

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("FacebookResults");

		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {

			JSONObject data = new JSONObject();
			data.put("Content", document.getString("post"));
			data.put("Words", document.getString("bad words"));
			data.put("Intent", document.getString("intent"));
			data.put("Emotion", document.getString("emotion"));
			data.put("Sentiment", document.getString("sentiment"));
			data.put("Review", document.getString("review"));
			array.put(data);
		}

		mongo.close();
		System.out.println(array);
		return array;

	}

	public JSONArray getYoutubeCommentsfromDB() {

		JSONArray array = new JSONArray();

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("YoutubeResults");

		FindIterable<Document> iterDoc = collection.find();
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {

			JSONObject data = new JSONObject();
			// data.put("Content", document.getString("content"));
			// data.put("Toxicity", document.getString("toxicity"));
			data.put("Intent", document.getString("intent"));
			data.put("Emotion", document.getString("emotion"));
			data.put("Sentiment", document.getString("sentiment"));
			data.put("Review", document.getString("review"));
			// data.put("Date", document.getString("date"));
			array.put(data);
		}

		mongo.close();
		System.out.println(array);
		return array;

	}

	public JSONArray getInstaPostsfromDB() {

		JSONArray array = new JSONArray();

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("InstagramResults");

		FindIterable<Document> iterDoc = collection.find();
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());
		System.out.println("doc="+documents);
		for (Document document : documents) {

			JSONObject data = new JSONObject();
			// data.put("Content", document.getString("content"));
			// data.put("Toxicity", document.getString("toxicity"));
			data.put("Intent", document.getString("intent"));
			data.put("Emotion", document.getString("emotion"));
			data.put("Sentiment", document.getString("sentiment"));
			data.put("Review", document.getString("review"));
			// data.put("Date", document.getString("date"));
			array.put(data);
		}

		mongo.close();
		System.out.println(array);
		return array;

	}

	public JSONArray getTweetsfromDB() {

		JSONArray array = new JSONArray();

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("CM");
		MongoCollection<Document> collection = db.getCollection("TwitterSearchResults");

		FindIterable<Document> iterDoc = collection.find();
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {

			JSONObject data = new JSONObject();
			data.put("Tweet", document.getString("tweet"));
			data.put("Words", document.getString("badwords"));
			data.put("Intent", document.getString("intent"));
			data.put("Emotion", document.getString("emotion"));
			data.put("Sentiment", document.getString("sentiment"));
			data.put("Image", document.getString("image"));
			data.put("Review", document.getString("review"));

			array.put(data);
		}

		mongo.close();
		System.out.println("array="+array);
		return array;

	}

	public JSONArray getTweetsBasedOnCompany(String company) {

		JSONArray array = new JSONArray();

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("TwitterResults");

		FindIterable<Document> iterDoc = collection.find();
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {

			if (document.getString("company").equalsIgnoreCase(company)) {
				JSONObject data = new JSONObject();
				data.put("Tweet", document.getString("tweet"));
				data.put("Words", document.getString("bad words"));
				data.put("Intent", document.getString("intent"));
				data.put("Emotion", document.getString("emotion"));
				data.put("Sentiment", document.getString("sentiment"));
				data.put("Image", document.getString("image"));
				data.put("Review", document.getString("review"));
				array.put(data);
			}

		}

		mongo.close();
		System.out.println(array);
		return array;

	}

	public JSONArray getFacebookPostsBasedOnCompany(String company) {

		JSONArray array = new JSONArray();

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("FacebookResults");

		FindIterable<Document> iterDoc = collection.find();
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {

			if (document.getString("company").equalsIgnoreCase(company)) {
				JSONObject data = new JSONObject();
				data.put("Post", document.getString("post"));
				data.put("Words", document.getString("bad words"));
				data.put("Intent", document.getString("intent"));
				data.put("Emotion", document.getString("emotion"));
				data.put("Sentiment", document.getString("sentiment"));
				data.put("Review", document.getString("review"));
				data.put("Type", document.getString("type"));
				array.put(data);
			}

		}

		mongo.close();
		System.out.println(array);
		return array;

	}

	public JSONArray getInstagramPostsBasedOnCompany(String company) {

		JSONArray array = new JSONArray();

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("InstagramResults");

		FindIterable<Document> iterDoc = collection.find();
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {

			if (document.getString("company").equalsIgnoreCase(company)) {
				JSONObject data = new JSONObject();
				data.put("Post", document.getString("post"));
				data.put("Words", document.getString("bad words"));
				data.put("Intent", document.getString("intent"));
				data.put("Emotion", document.getString("emotion"));
				data.put("Sentiment", document.getString("sentiment"));
				data.put("Review", document.getString("review"));
				data.put("Image", document.getString("image"));
				array.put(data);
			}

		}

		mongo.close();
		System.out.println(array);
		return array;

	}

	public JSONArray getImagefromDB() {

		JSONArray array = new JSONArray();

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("Images");

		FindIterable<Document> iterDoc = collection.find();
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {

			JSONObject data = new JSONObject();
			data.put("url", document.getString("url"));
			data.put("review", document.getString("review"));
			data.put("category", document.getString("category"));
			data.put("date", document.getString("date"));

			array.put(data);
		}

		mongo.close();
		System.out.println(array);
		return array;

	}

	
	public JSONArray checkResourceUsed(String service) {

		JSONArray array = new JSONArray();

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("Resources");

		FindIterable<Document> iterDoc = collection.find();
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {
			
			if(document.getString("service").equalsIgnoreCase(service))
			{
			JSONObject data = new JSONObject();
			data.put("service", document.getString("service"));
			data.put("count", document.getInteger("count"));
			data.put("Date", document.getString("date"));
			array.put(data);
			}
		}

		mongo.close();
		return array;

	}
	
	public JSONArray checkModerateContentUsed() {

		JSONArray array = new JSONArray();

		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("Resources");

		FindIterable<Document> iterDoc = collection.find();
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {

			JSONObject data = new JSONObject();
			data.put("provider", document.getString("provider"));
			data.put("count", document.getString("count"));
			data.put("date", document.getString("date"));
			array.put(data);
		}

		mongo.close();
		System.out.println(array);
		return array;

	}

	public JSONArray fetchDataUsingFilterPosts(String sentiment, String intent, String platform, String review)
			throws ParseException, FileNotFoundException, IOException, org.json.simple.parser.ParseException {

		System.out.println("Sentiment"+sentiment);
		System.out.println("intent"+intent);
		
		JSONArray array = new JSONArray();
		int casing = 0;
		if (!sentiment.equalsIgnoreCase("none") && !intent.equalsIgnoreCase("none")) {
			casing = 1;
		} else if (sentiment.equalsIgnoreCase("none") && intent.equalsIgnoreCase("none")) {
			casing = 2;
		} else if ((!intent.equalsIgnoreCase("none")) && sentiment.equalsIgnoreCase("none")) {
			casing = 3;
		} else {
			casing = 4;
		}
		System.out.println("casing"+casing);
		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("CM");
		MongoCollection<Document> collection = db.getCollection(platform);

		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		if (casing == 1) {
			// case-1 all 3 given
			for (Document document : documents) {
				JSONObject obj = new JSONObject();
				if (sentiment.toString().equalsIgnoreCase(document.getString("sentiment"))
						&& intent.toString().equalsIgnoreCase(document.getString("intent"))) {
					System.out.println("matching cases");
					if (review.equalsIgnoreCase(document.getString("review"))) {
						obj.put("Tweets", document.getString("tweet"));
						obj.put("Badwords", document.getString("badwords"));
						obj.put("Intent", document.getString("intent"));
						obj.put("Emotion", document.getString("emotion"));
						obj.put("Sentiment", document.getString("sentiment"));
						obj.put("Images", document.getString("image result"));
						obj.put("Review", document.getString("review"));
						obj.put("date", document.getString("date"));
						array.put(obj);
					}
				}

			}
		} else if (casing == 2) {
			// case- 2 only company given
			for (Document document : documents) {
				JSONObject obj = new JSONObject();
				if (review.toString().equalsIgnoreCase(document.getString("review"))) {
					System.out.println("matching cases");
					obj.put("Tweets", document.getString("tweet"));
					obj.put("Badwords", document.getString("badwords"));
					obj.put("Intent", document.getString("intent"));
					obj.put("Emotion", document.getString("emotion"));
					obj.put("Sentiment", document.getString("sentiment"));
					obj.put("Images", document.getString("image result"));
					obj.put("Review", document.getString("review"));
					obj.put("date", document.getString("date"));
					array.put(obj);
				}
			}

		} else if (casing == 3) {
			// case- 3 company and intent given

			for (Document document : documents) {
				JSONObject obj = new JSONObject();
				if (review.toString().equalsIgnoreCase(document.getString("review"))
						&& intent.toString().equalsIgnoreCase(document.getString("intent"))) {
					System.out.println("matching cases");
					obj.put("Tweets", document.getString("tweet"));
					obj.put("Badwords", document.getString("badwords"));
					obj.put("Intent", document.getString("intent"));
					obj.put("Emotion", document.getString("emotion"));
					obj.put("Sentiment", document.getString("sentiment"));
					obj.put("Images", document.getString("image result"));
					obj.put("Review", document.getString("review"));
					obj.put("date", document.getString("date"));
					array.put(obj);
				}

			}
		} else // only company and sentiment given
		{
			for (Document document : documents) {
				JSONObject obj = new JSONObject();
				if (review.toString().equalsIgnoreCase(document.getString("review"))
						&& sentiment.toString().equalsIgnoreCase(document.getString("sentiment"))) {
					System.out.println("matching cases");
					obj.put("Tweets", document.getString("tweet"));
					obj.put("Badwords", document.getString("badwords"));
					obj.put("Intent", document.getString("intent"));
					obj.put("Emotion", document.getString("emotion"));
					obj.put("Sentiment", document.getString("sentiment"));
					obj.put("Images", document.getString("image result"));
					obj.put("Review", document.getString("review"));
					obj.put("date", document.getString("date"));
					array.put(obj);
				}

			}
		}
		if(array.length()==0)
		{
			JSONObject obj =new JSONObject();
			obj.put("responses", "empty");
			
			array.put(obj);
		}

		mongo.close();
		return array;
	}

	public JSONArray fetchDataUsingFilterPosts1(String sentiment, String intent, String platform)
			throws ParseException, FileNotFoundException, IOException, org.json.simple.parser.ParseException {

		
		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection(platform);

		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		
			JSONArray array = new JSONArray();
			for (Document document : documents) {
				JSONObject obj = new JSONObject();
				if (sentiment.toString().equalsIgnoreCase(document.getString("sentiment"))
						|| intent.toString().equalsIgnoreCase(document.getString("intent"))) {
					System.out.println("matching cases");
					
						obj.put("Intent", document.getString("intent"));
						obj.put("Emotion", document.getString("emotion"));
						obj.put("Sentiment", document.getString("sentiment"));
						obj.put("Review", document.getString("review"));
						array .put(obj);
					
				}

			}
			if(array.length()==0)
			{
				JSONObject obj =new JSONObject();
				obj.put("responses", "empty");
				
				array.put(obj);
			}
	
		mongo.close();
		return array;
	}
	public JSONArray getRangeTwitterImage(String start, String end) throws ParseException {
		SimpleDateFormat s = new SimpleDateFormat("yyyy/MM/dd");
		Date starting = s.parse(start);
		System.out.println(starting);
		Date ending = s.parse(end);
		System.out.println(ending);
		JSONArray array = new JSONArray();
		int range = 0;
		MongoClient mongo = new MongoClient("localhost", 27017);
		MongoDatabase db = mongo.getDatabase("ContentModeration");
		MongoCollection<Document> collection = db.getCollection("Images");

		FindIterable<Document> iterDoc = collection.find();
		List<Document> documents = (List<Document>) collection.find().into(new ArrayList<Document>());

		for (Document document : documents) {

			String date = document.getString("date");
			Date post_date = s.parse(date);
			if (post_date.getTime() >= starting.getTime() && post_date.getTime() <= ending.getTime()) {
				range++;
				JSONObject data = new JSONObject();
				data.put("url", document.getString("url"));
				data.put("review", document.getString("review"));
				data.put("category", document.getString("category"));
				data.put("date", document.getString("date"));
				array.put(data);
			}

		}
		mongo.close();
		return array;
	}

	public JSONArray getRange(String start, String end, JSONArray ar) throws ParseException {
		try {
		JSONArray array = new JSONArray();
		SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = s.parse(start);
		System.out.println("starttt="+startDate);
		Date endDate = s.parse(end);
		System.out.println(endDate);
		
		int i=0 ;
		while(i<ar.length())
		{
			JSONObject ob = ar.getJSONObject(i);
			String postDate = ob.getString("date");
			Date post_date = s.parse(postDate);
			if(post_date.getTime() >= startDate.getTime() && post_date.getTime() <= endDate.getTime())
			{
				array.put(ob);
			}
			i++;
		}
		if(array.length()==0)
		{
			JSONObject obj =new JSONObject();
			obj.put("responses", "empty");
			
			array.put(obj);
		}
		
		return array;
		}
		catch(Exception e)
		{
			
			JSONArray array = new JSONArray();
			JSONObject obj =new JSONObject();
			obj.put("responses", "empty");
			
			array.put(obj);
			return array;
		}
		}

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		Database d = new Database();
		JSONArray a = new JSONArray();

	}

}
